export function hasChildNodes(
  node: Element,
): boolean {
  return node.childNodes.length > 0;
}

