export const MATH_ML_NAMESPACE_URI_CONSTANT = 'http://www.w3.org/1998/Math/MathML';
