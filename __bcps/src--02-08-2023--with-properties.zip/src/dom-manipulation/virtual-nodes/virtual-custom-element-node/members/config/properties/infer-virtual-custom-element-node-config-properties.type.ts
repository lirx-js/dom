import { IVirtualCustomElementNodeConfig } from '../virtual-custom-element-node-config.type';
import { IVirtualCustomElementNodeConfigProperties } from './virtual-custom-element-node-config-properties.type';

export type InferVirtualCustomElementNodeConfigProperties<GConfig extends IVirtualCustomElementNodeConfig> =
  GConfig['properties'] extends IVirtualCustomElementNodeConfigProperties
    ? GConfig['properties']
    : never;
