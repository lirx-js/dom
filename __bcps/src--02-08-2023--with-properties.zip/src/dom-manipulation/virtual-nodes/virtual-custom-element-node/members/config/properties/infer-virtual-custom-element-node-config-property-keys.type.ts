import { InferVirtualCustomElementNodePropertyMapKeys } from '../../properties/virtual-custom-element-node-properties.class';
import { IVirtualCustomElementNodeConfig } from '../virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeConfigProperties } from './infer-virtual-custom-element-node-config-properties.type';

export type InferVirtualCustomElementNodeConfigPropertyKeys<GConfig extends IVirtualCustomElementNodeConfig> =
  InferVirtualCustomElementNodePropertyMapKeys<InferVirtualCustomElementNodeConfigProperties<GConfig>>;

