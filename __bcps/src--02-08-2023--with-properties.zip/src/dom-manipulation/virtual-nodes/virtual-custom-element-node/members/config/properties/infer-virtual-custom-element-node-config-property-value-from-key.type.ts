import { InferVirtualCustomElementNodePropertyMapValueFromKey } from '../../properties/virtual-custom-element-node-properties.class';
import { IVirtualCustomElementNodeConfig } from '../virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeConfigProperties } from './infer-virtual-custom-element-node-config-properties.type';
import { InferVirtualCustomElementNodeConfigPropertyKeys } from './infer-virtual-custom-element-node-config-property-keys.type';

export type InferVirtualCustomElementNodeConfigPropertyValueFromKey<GConfig extends IVirtualCustomElementNodeConfig, GKey extends InferVirtualCustomElementNodeConfigPropertyKeys<GConfig>> =
  InferVirtualCustomElementNodePropertyMapValueFromKey<InferVirtualCustomElementNodeConfigProperties<GConfig>, GKey>;
