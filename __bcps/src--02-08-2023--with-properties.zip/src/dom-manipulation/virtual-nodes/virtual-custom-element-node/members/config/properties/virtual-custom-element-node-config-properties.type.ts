import { IGenericVirtualCustomElementProperty } from '../../properties/virtual-custom-element-node-properties.class';

export type IVirtualCustomElementNodeConfigProperties = IGenericVirtualCustomElementProperty;

