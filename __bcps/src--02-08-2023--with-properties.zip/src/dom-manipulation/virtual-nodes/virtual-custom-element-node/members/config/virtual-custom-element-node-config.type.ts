import { IVirtualCustomElementNodeConfigProperties } from './properties/virtual-custom-element-node-config-properties.type';

export interface IVirtualCustomElementNodeConfig {
  element?: Element;
  properties?: IVirtualCustomElementNodeConfigProperties;
}
