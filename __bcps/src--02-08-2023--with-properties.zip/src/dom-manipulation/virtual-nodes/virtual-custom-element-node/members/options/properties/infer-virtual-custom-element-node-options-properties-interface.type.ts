import {
  InferVirtualCustomElementNodeConfigProperties,
} from '../../config/properties/infer-virtual-custom-element-node-config-properties.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeOptionsProperties } from './infer-virtual-custom-element-node-options-properties.type';

export type InferVirtualCustomElementNodeOptionsPropertiesInterface<GConfig extends IVirtualCustomElementNodeConfig> =
  InferVirtualCustomElementNodeConfigProperties<GConfig> extends never
    ? {
      properties?: Iterable<never> | readonly [];
    }
    : {
      properties: InferVirtualCustomElementNodeOptionsProperties<GConfig>,
    }
  ;

