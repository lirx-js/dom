import {
  InferVirtualCustomElementNodeConfigProperties,
} from '../../config/properties/infer-virtual-custom-element-node-config-properties.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodePropertyMapInputProperties } from '../../properties/virtual-custom-element-node-properties.class';

export type InferVirtualCustomElementNodeOptionsProperties<GConfig extends IVirtualCustomElementNodeConfig> =
  InferVirtualCustomElementNodePropertyMapInputProperties<InferVirtualCustomElementNodeConfigProperties<GConfig>>
  ;
