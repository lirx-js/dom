import { IVirtualCustomElementNodeConfig } from '../config/virtual-custom-element-node-config.type';
import { IVirtualCustomElementNodeSlotsMap } from '../slots/virtual-custom-element-node-slots-map.type';
import {
  InferVirtualCustomElementNodeOptionsPropertiesInterface,
} from './properties/infer-virtual-custom-element-node-options-properties-interface.type';

export type IVirtualCustomElementNodeOptions<GConfig extends IVirtualCustomElementNodeConfig> = {
    name: string;
    extends?: string;
    namespaceURI?: string,
    slots: IVirtualCustomElementNodeSlotsMap;
  }
  & InferVirtualCustomElementNodeOptionsPropertiesInterface<GConfig>
  ;
