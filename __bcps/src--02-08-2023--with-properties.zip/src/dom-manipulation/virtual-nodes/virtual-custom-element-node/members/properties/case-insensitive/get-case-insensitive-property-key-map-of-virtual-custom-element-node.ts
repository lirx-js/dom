import { CaseInsensitiveKeyMap, IGenericCaseInsensitiveKeyMap } from '../../../../../../misc/classes/case-insensitive-key-map.class';
import { VirtualCustomElementNode } from '../../../virtual-custom-element-node.class';
import {
  InferVirtualCustomElementNodeConfigProperties,
} from '../../config/properties/infer-virtual-custom-element-node-config-properties.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  IGenericVirtualCustomElementNodePropertyMap,
  IGenericVirtualCustomElementProperty,
  InferVirtualCustomElementNodePropertyMapKeys,
  VirtualCustomElementNodePropertyMap,
} from '../virtual-custom-element-node-properties.class';

export function getCaseInsensitivePropertyKeyMapOfVirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig>(
  node: VirtualCustomElementNode<GConfig>,
): CaseInsensitiveKeyMap<InferVirtualCustomElementNodePropertyMapKeys<InferVirtualCustomElementNodeConfigProperties<GConfig>>> {
  return getCaseInsensitivePropertyKeyMapOfVirtualCustomElementNodeProperties<InferVirtualCustomElementNodeConfigProperties<GConfig>>(node.properties);
}

const CACHE = new WeakMap<IGenericVirtualCustomElementNodePropertyMap, IGenericCaseInsensitiveKeyMap>();

function getCaseInsensitivePropertyKeyMapOfVirtualCustomElementNodeProperties<GProperty extends IGenericVirtualCustomElementProperty>(
  properties: VirtualCustomElementNodePropertyMap<GProperty>,
): CaseInsensitiveKeyMap<InferVirtualCustomElementNodePropertyMapKeys<GProperty>> {
  let map: CaseInsensitiveKeyMap<InferVirtualCustomElementNodePropertyMapKeys<GProperty>> | undefined = CACHE.get(properties);
  if (map === void 0) {
    map = createCaseInsensitivePropertyKeyMapOfVirtualCustomElementNodeProperties<GProperty>(properties);
    CACHE.set(properties, map);
  }
  return map;
}

function createCaseInsensitivePropertyKeyMapOfVirtualCustomElementNodeProperties<GProperty extends IGenericVirtualCustomElementProperty>(
  properties: VirtualCustomElementNodePropertyMap<GProperty>,
): CaseInsensitiveKeyMap<InferVirtualCustomElementNodePropertyMapKeys<GProperty>> {
  return new CaseInsensitiveKeyMap<InferVirtualCustomElementNodePropertyMapKeys<GProperty>>(
    properties.keys(),
  );
}
