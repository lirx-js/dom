import { VirtualCustomElementNode } from '../../../virtual-custom-element-node.class';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  getCaseInsensitivePropertyKeyMapOfVirtualCustomElementNode,
} from './get-case-insensitive-property-key-map-of-virtual-custom-element-node';
import {
  InferCaseInsensitivePropertyKeyOfVirtualCustomElementNode,
} from './infer-case-insensitive-property-key-of-virtual-custom-element-node.type';

export function getCaseInsensitivePropertyKeyOfVirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string>(
  node: VirtualCustomElementNode<GConfig>,
  key: GCaseInsensitiveKey,
): InferCaseInsensitivePropertyKeyOfVirtualCustomElementNode<GConfig, GCaseInsensitiveKey> {
  return getCaseInsensitivePropertyKeyMapOfVirtualCustomElementNode<GConfig>(node).get<GCaseInsensitiveKey>(key);
}
