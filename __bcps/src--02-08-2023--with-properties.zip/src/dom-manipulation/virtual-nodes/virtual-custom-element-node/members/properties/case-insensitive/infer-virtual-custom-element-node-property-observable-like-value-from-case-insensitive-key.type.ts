import { IObservableLike, INotAnObservable } from '@lirx/core';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  InferVirtualCustomElementNodePropertyValueFromCaseInsensitiveKey,
} from './infer-virtual-custom-element-node-property-value-from-case-insensitive-key.type';

export type InferVirtualCustomElementNodePropertyObservableLikeValueFromCaseInsensitiveKey<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string> =
  InferVirtualCustomElementNodePropertyValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey> extends INotAnObservable<InferVirtualCustomElementNodePropertyValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>>
    ? IObservableLike<InferVirtualCustomElementNodePropertyValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>>
    : never;
