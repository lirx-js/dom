import { toObservableThrowIfUndefined } from '@lirx/core';
import { IUnsubscribe } from '@lirx/utils';
import { VirtualCustomElementNode } from '../../../../virtual-custom-element-node.class';
import { IVirtualCustomElementNodeConfig } from '../../../config/virtual-custom-element-node-config.type';
import {
  InferVirtualCustomElementNodePropertyObservableLikeValueFromCaseInsensitiveKey,
} from '../infer-virtual-custom-element-node-property-observable-like-value-from-case-insensitive-key.type';
import {
  bindCaseInsensitiveInputOfVirtualCustomElementNodeWithObservable,
} from './bind-case-insensitive-input-of-virtual-custom-element-node-with-observable';

export function bindCaseInsensitiveInputOfVirtualCustomElementNodeWithObservableLike<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string>(
  node: VirtualCustomElementNode<GConfig>,
  key: GCaseInsensitiveKey,
  value$: InferVirtualCustomElementNodePropertyObservableLikeValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>,
): IUnsubscribe {
  return bindCaseInsensitiveInputOfVirtualCustomElementNodeWithObservable(
    node,
    key,
    toObservableThrowIfUndefined(value$),
  );
}
