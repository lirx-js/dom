import { IObserver } from '@lirx/core';
import { IUnsubscribe } from '@lirx/utils';
import { VirtualCustomElementNode } from '../../../../virtual-custom-element-node.class';
import {
  InferVirtualCustomElementNodeConfigPropertyValueFromKey,
} from '../../../config/properties/infer-virtual-custom-element-node-config-property-value-from-key.type';
import { IVirtualCustomElementNodeConfig } from '../../../config/virtual-custom-element-node-config.type';
import {
  getCaseInsensitivePropertyKeyOfVirtualCustomElementNode,
} from '../get-case-insensitive-property-key-of-virtual-custom-element-node';
import {
  InferCaseInsensitivePropertyKeyOfVirtualCustomElementNode,
} from '../infer-case-insensitive-property-key-of-virtual-custom-element-node.type';
import {
  InferVirtualCustomElementNodePropertyValueFromCaseInsensitiveKey,
} from '../infer-virtual-custom-element-node-property-value-from-case-insensitive-key.type';

export function bindCaseInsensitiveOutputOfVirtualCustomElementNodeWithObserver<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string>(
  node: VirtualCustomElementNode<GConfig>,
  key: GCaseInsensitiveKey,
  $value: IObserver<InferVirtualCustomElementNodePropertyValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>>,
): IUnsubscribe {
  type GKey = InferCaseInsensitivePropertyKeyOfVirtualCustomElementNode<GConfig, GCaseInsensitiveKey>;
  return node.bindOutputWithObserver<GKey>(
    getCaseInsensitivePropertyKeyOfVirtualCustomElementNode<GConfig, GCaseInsensitiveKey>(node, key),
    $value as IObserver<InferVirtualCustomElementNodeConfigPropertyValueFromKey<GConfig, GKey>>,
  );
}
