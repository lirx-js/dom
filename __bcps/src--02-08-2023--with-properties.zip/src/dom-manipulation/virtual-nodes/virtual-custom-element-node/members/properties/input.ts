import { createMulticastReplayLastSource, IMulticastReplayLastSource, ICreateReplayLastSourceInitialValue } from '@lirx/core';

export type IInput<GKey extends string, GValue> = readonly [
  key: GKey,
  sourceFactory: () => IMulticastReplayLastSource<GValue>,
];

export function input<GKey extends string, GValue = any>(
  key: GKey,
  ...initialValue: ICreateReplayLastSourceInitialValue<GValue>
): IInput<GKey, GValue> {
  return [
    key,
    () => createMulticastReplayLastSource<GValue>(...initialValue),
  ];
}
