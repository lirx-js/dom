import { createMulticastSource, IMulticastSource } from '@lirx/core';

export type IOutput<GKey extends string, GValue> = readonly [
  key: GKey,
  source: () => IMulticastSource<GValue>,
];

export function output<GKey extends string, GValue = any>(
  key: GKey,
): IOutput<GKey, GValue> {
  return [
    key,
    () => createMulticastSource<GValue>(),
  ];
}
