import { IObservable, IObserver, ISource, readObservableValue } from '@lirx/core';
import { InferTypedMapKeys, InferTypedMapValueFromKey, ITypedMapEntry, TypedMap, InferTypedMapHasValueFromKey } from '@lirx/utils';

/** TYPES **/

// ENTRY

export type IVirtualCustomElementProperty<GKey extends string, GValue> = ITypedMapEntry<GKey, GValue>;

export type IGenericVirtualCustomElementProperty = IVirtualCustomElementProperty<any, any>;

// KEYS AND VALUES
export type InferVirtualCustomElementNodePropertyMapKeys<GProperty extends IGenericVirtualCustomElementProperty> = InferTypedMapKeys<GProperty>;

export type InferVirtualCustomElementNodePropertyMapHasValueFromKey<GProperty extends IGenericVirtualCustomElementProperty, GKey extends string> =
  InferTypedMapHasValueFromKey<GProperty, GKey>;

export type InferVirtualCustomElementNodePropertyMapValueFromKey<GProperty extends IGenericVirtualCustomElementProperty, GKey extends InferVirtualCustomElementNodePropertyMapKeys<GProperty>> =
  InferTypedMapValueFromKey<GProperty, GKey>;

// INPUT
export type InferVirtualCustomElementNodePropertyMapInputProperty<GProperty extends IGenericVirtualCustomElementProperty> =
  GProperty extends readonly [infer GKey, infer GValue]
    ? readonly [GKey, () => ISource<GValue>]
    : never
  ;

export type InferVirtualCustomElementNodePropertyMapInputProperties<GProperty extends IGenericVirtualCustomElementProperty> = Iterable<InferVirtualCustomElementNodePropertyMapInputProperty<GProperty>>;

// MAP
export type InferVirtualCustomElementNodePropertyMapEntry<GProperty extends IGenericVirtualCustomElementProperty> =
  GProperty extends readonly [infer GKey, infer GValue]
    ? readonly [GKey, ISource<GValue>]
    : never;

/** CLASS **/

export class VirtualCustomElementNodePropertyMap<GProperty extends IGenericVirtualCustomElementProperty> {
  readonly #map: TypedMap<InferVirtualCustomElementNodePropertyMapEntry<GProperty>>;

  constructor(
    properties: InferVirtualCustomElementNodePropertyMapInputProperties<GProperty>,
  ) {
    this.#map = new TypedMap<InferVirtualCustomElementNodePropertyMapEntry<GProperty>>(
      Array.from(properties, ([key, sourceFactory]: InferVirtualCustomElementNodePropertyMapInputProperty<GProperty>): InferVirtualCustomElementNodePropertyMapEntry<GProperty> => {
        return [
          key,
          sourceFactory(),
        ] as unknown as InferVirtualCustomElementNodePropertyMapEntry<GProperty>;
      }),
    );
  }

  has<GKey extends string>(
    key: GKey,
  ): InferVirtualCustomElementNodePropertyMapHasValueFromKey<GProperty, GKey> {
    return this.#map.has<GKey>(key) as any;
  }

  source<GKey extends InferVirtualCustomElementNodePropertyMapKeys<GProperty>>(
    key: GKey,
  ): ISource<InferVirtualCustomElementNodePropertyMapValueFromKey<GProperty, GKey>> {
    return this.#map.get<GKey>(key);
  }

  get$<GKey extends InferVirtualCustomElementNodePropertyMapKeys<GProperty>>(
    key: GKey,
  ): IObservable<InferVirtualCustomElementNodePropertyMapValueFromKey<GProperty, GKey>> {
    return this.source<GKey>(key).subscribe;
  }

  get<GKey extends InferVirtualCustomElementNodePropertyMapKeys<GProperty>>(
    key: GKey,
  ): InferVirtualCustomElementNodePropertyMapValueFromKey<GProperty, GKey> {
    return readObservableValue(this.get$<GKey>(key), (): never => {
      throw new Error(`Unable to read: ${key}`);
    });
  }

  $set<GKey extends InferVirtualCustomElementNodePropertyMapKeys<GProperty>>(
    key: GKey,
  ): IObserver<InferVirtualCustomElementNodePropertyMapValueFromKey<GProperty, GKey>> {
    return this.source<GKey>(key).emit;
  }

  set<GKey extends InferVirtualCustomElementNodePropertyMapKeys<GProperty>>(
    key: GKey,
    value: InferVirtualCustomElementNodePropertyMapValueFromKey<GProperty, GKey>,
  ): void {
    this.$set<GKey>(key)(value);
  }

  keys(): IterableIterator<InferVirtualCustomElementNodePropertyMapKeys<GProperty>> {
    return this.#map.keys();
  }
}

export type IGenericVirtualCustomElementNodePropertyMap = VirtualCustomElementNodePropertyMap<any>

/*---------------------*/

/*---------------------*/
//
// type A =
//   | ['A', string]
//   | ['b', boolean]
// ;
//
// const a = new VirtualCustomElementNodePropertyMap<A>([
//   ['A', '0'],
//   ['b', false],
// ]);
//
// const b = a.get$('A');
