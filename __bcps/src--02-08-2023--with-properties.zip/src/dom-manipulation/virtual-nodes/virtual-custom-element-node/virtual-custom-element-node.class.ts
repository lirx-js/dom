import { IObservable, IObserver, subscribeToObservableUsingAnObservableOfObserver } from '@lirx/core';
import { IUnsubscribe } from '@lirx/utils';
import { HTML_NAMESPACE_URI_CONSTANT } from '../../misc/namespace-uri/html-namespace-uri.constant';
import { VirtualReactiveElementNode } from '../virtual-reactive-element-node/virtual-reactive-element-node.class';
import { InferVirtualCustomElementNodeConfigElement } from './members/config/infer-virtual-custom-element-node-config-element.type';
import {
  InferVirtualCustomElementNodeConfigProperties,
} from './members/config/properties/infer-virtual-custom-element-node-config-properties.type';
import {
  InferVirtualCustomElementNodeConfigPropertyKeys,
} from './members/config/properties/infer-virtual-custom-element-node-config-property-keys.type';
import {
  InferVirtualCustomElementNodeConfigPropertyValueFromKey,
} from './members/config/properties/infer-virtual-custom-element-node-config-property-value-from-key.type';
import { IVirtualCustomElementNodeConfig } from './members/config/virtual-custom-element-node-config.type';
import { IVirtualCustomElementNodeOptions } from './members/options/virtual-custom-element-node-options.type';
import { VirtualCustomElementNodePropertyMap } from './members/properties/virtual-custom-element-node-properties.class';
import { IVirtualCustomElementNodeSlotsMap } from './members/slots/virtual-custom-element-node-slots-map.type';

/**
 * Represents an instance of a Component.
 * It has:
 * - a name
 * - some slots
 * - and some 'properties'
 */
export class VirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig> extends VirtualReactiveElementNode<InferVirtualCustomElementNodeConfigElement<GConfig>> {
  readonly #name: string;
  readonly #extends: string | undefined;
  readonly #slots: IVirtualCustomElementNodeSlotsMap;

  readonly #properties: VirtualCustomElementNodePropertyMap<InferVirtualCustomElementNodeConfigProperties<GConfig>>;

  constructor(
    {
      name,
      extends: _extends,
      namespaceURI = HTML_NAMESPACE_URI_CONSTANT,
      slots,
      properties = [],
    }: IVirtualCustomElementNodeOptions<GConfig>,
  ) {
    super(
      namespaceURI,
      (_extends === void 0)
        ? name
        : _extends,
    );
    this.#name = name;
    this.#extends = _extends;
    this.#slots = slots;
    this.#properties = new VirtualCustomElementNodePropertyMap<InferVirtualCustomElementNodeConfigProperties<GConfig>>(properties);

    if (_extends !== void 0) {
      this.setAttribute('is', name);
    }
  }

  get name(): string {
    return this.#name;
  }

  get extends(): string | undefined {
    return this.#extends;
  }

  get slots(): IVirtualCustomElementNodeSlotsMap {
    return this.#slots;
  }

  get properties(): VirtualCustomElementNodePropertyMap<InferVirtualCustomElementNodeConfigProperties<GConfig>> {
    return this.#properties;
  }

  bindInputWithObservable<GKey extends InferVirtualCustomElementNodeConfigPropertyKeys<GConfig>>(
    key: GKey,
    value$: IObservable<InferVirtualCustomElementNodeConfigPropertyValueFromKey<GConfig, GKey>>,
  ): IUnsubscribe {
    return this.onConnected((): IUnsubscribe => {
      return value$(this.properties.$set<GKey>(key));
    });
  }

  bindOutputWithObserver<GKey extends InferVirtualCustomElementNodeConfigPropertyKeys<GConfig>>(
    key: GKey,
    $value: IObserver<InferVirtualCustomElementNodeConfigPropertyValueFromKey<GConfig, GKey>>,
  ): IUnsubscribe {
    return this.onConnected((): IUnsubscribe => {
      return this.properties.get$<GKey>(key)($value);
    });
  }

  bindOutputWithObservableOfObserver<GKey extends InferVirtualCustomElementNodeConfigPropertyKeys<GConfig>>(
    key: GKey,
    $value: IObservable<IObserver<InferVirtualCustomElementNodeConfigPropertyValueFromKey<GConfig, GKey>>>,
  ): IUnsubscribe {

    return this.onConnected((): IUnsubscribe => {
      return subscribeToObservableUsingAnObservableOfObserver<InferVirtualCustomElementNodeConfigPropertyValueFromKey<GConfig, GKey>>(
        this.properties.get$<GKey>(key),
        $value,
      );
    });
  }
}

/*-------------------*/

/*-------------------*/

// interface TestConfig {
//   element: HTMLButtonElement;
//   properties:
//     | ['i-a', boolean]
//     | ['o-a', number]
//     | ['o-b', string]
//   ,
// }
//
// const a = new VirtualCustomElementNode<TestConfig>({
//   name: 'test',
//   slots: new Map(),
//   properties: [
//     ['i-a', true],
//     'o-b',
//     ['o-a'],
//   ],
// });
//
//
// a.properties.get('i-a');
// a.properties.set('o-a', 4);

// a.setReactiveInput('i-a', single(true))
// a.setReactiveOutput('i-a', (value: boolean) => {})
// a.setReactiveOutput('o-a', (value: number) => {})
