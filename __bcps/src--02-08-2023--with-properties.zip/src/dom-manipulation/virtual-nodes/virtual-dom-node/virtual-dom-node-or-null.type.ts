import { VirtualDOMNode } from './virtual-dom-node.class';

export type IVirtualDOMNodeOrNull = VirtualDOMNode | null;
