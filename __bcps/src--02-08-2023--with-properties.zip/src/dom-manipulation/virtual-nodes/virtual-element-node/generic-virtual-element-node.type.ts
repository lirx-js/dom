import { VirtualElementNode } from './virtual-element-node.class';

export type IGenericVirtualElementNode = VirtualElementNode<any>;
