import { VirtualNode } from './virtual-node.class';

export type IVirtualNodeOrNull = VirtualNode | null;
