export type IMappedAttributes = Map<string, string>;
