import { IUnsubscribe } from '@lirx/utils';
import {
  IVirtualCustomElementNodeConfig,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/members/config/virtual-custom-element-node-config.type';
import {
  InferVirtualCustomElementNodePropertyObservableLikeValueFromCaseInsensitiveKey,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/members/properties/case-insensitive/infer-virtual-custom-element-node-property-observable-like-value-from-case-insensitive-key.type';
import {
  bindCaseInsensitiveInputOfVirtualCustomElementNodeWithObservableLike,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/members/properties/case-insensitive/input/bind-case-insensitive-input-of-virtual-custom-element-node-with-observable-like';
import {
  VirtualCustomElementNode,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/virtual-custom-element-node.class';
import { inlineLastLines } from '../../../../../misc/lines/functions/after-last-line';
import { ILines } from '../../../../../misc/lines/lines.type';
import {
  ITranspileSetReactiveInputToJSLinesFunction,
  ITranspileSetReactiveInputToJSLinesOptions,
} from '../../transpilers/transpile-set-reactive-input-to-js-lines.type';

export const transpileAOTSetReactiveInputToJSLines: ITranspileSetReactiveInputToJSLinesFunction = (
  {
    node,
    name,
    value,
  }: ITranspileSetReactiveInputToJSLinesOptions,
): ILines => {
  return inlineLastLines(
    [`aot_16(`],
    node,
    [', '],
    name,
    [', '],
    value,
    [');'],
  );
};

export function aot_16<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string>(
  node: VirtualCustomElementNode<GConfig>,
  key: GCaseInsensitiveKey,
  value$: InferVirtualCustomElementNodePropertyObservableLikeValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>,
): IUnsubscribe {
  return bindCaseInsensitiveInputOfVirtualCustomElementNodeWithObservableLike<GConfig, GCaseInsensitiveKey>(
    node,
    key,
    value$,
  );
}

