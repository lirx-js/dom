import { function$$ } from '@lirx/core';

/**
 * @deprecated
 * @internal
 */
export const f$ = function$$;
