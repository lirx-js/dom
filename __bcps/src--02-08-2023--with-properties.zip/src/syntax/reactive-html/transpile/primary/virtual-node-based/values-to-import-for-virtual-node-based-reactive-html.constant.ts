import { toObservableThrowIfUndefined } from '@lirx/core';
import {
  bindCaseInsensitiveInputOfVirtualCustomElementNodeWithObservableLike,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/members/properties/case-insensitive/input/bind-case-insensitive-input-of-virtual-custom-element-node-with-observable-like';
import {
  bindCaseInsensitiveOutputOfVirtualCustomElementNodeWithObservableOfObserver,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/members/properties/case-insensitive/output/bind-case-insensitive-output-of-virtual-custom-element-node-with-observable-of-observer';
import {
  bindCaseInsensitiveOutputOfVirtualCustomElementNodeWithObserver,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/members/properties/case-insensitive/output/bind-case-insensitive-output-of-virtual-custom-element-node-with-observer';
import {
  virtualElementNodeAppendClassName,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-element-node/members/class-name/virtual-element-node-append-class-name';
import {
  VirtualReactiveAsyncNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-async-node/virtual-reactive-async-node.class';
import {
  virtualReactiveElementNodeSetCaseInsensitiveReactiveProperty,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-element-node/members/property/case-insensitive/virtual-reactive-element-node-set-case-insensitive-reactive-property';
import {
  VirtualReactiveElementNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-element-node/virtual-reactive-element-node.class';
import {
  VirtualReactiveForLoopNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-for-loop-node/virtual-reactive-for-loop-node.class';
import {
  VirtualReactiveIfNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-if-node/virtual-reactive-if-node.class';
import {
  VirtualReactiveSwitchNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-switch-node/virtual-reactive-switch-node.class';
import {
  VirtualReactiveTextNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-text-node/virtual-reactive-text-node.class';
import { VirtualTextNode } from '../../../../../dom-manipulation/virtual-nodes/virtual-text-node/virtual-text-node';
import { SHARED_VALUES_TO_IMPORT } from '../shared/values-to-import/shared-values-to-import.constant';

export const VALUES_TO_IMPORT_FOR_VIRTUAL_NODE_BASED_REACTIVE_HTML = {
  ...SHARED_VALUES_TO_IMPORT,
  VirtualTextNode,
  VirtualReactiveElementNode,
  VirtualReactiveTextNode,
  VirtualReactiveIfNode,
  VirtualReactiveSwitchNode,
  VirtualReactiveForLoopNode,
  VirtualReactiveAsyncNode,
  toObservableThrowIfUndefined,
  virtualElementNodeAppendClassName,
  virtualReactiveElementNodeSetCaseInsensitiveReactiveProperty,
  bindCaseInsensitiveInputOfVirtualCustomElementNodeWithObservableLike,
  bindCaseInsensitiveOutputOfVirtualCustomElementNodeWithObservableOfObserver,
  bindCaseInsensitiveOutputOfVirtualCustomElementNodeWithObserver,
};
