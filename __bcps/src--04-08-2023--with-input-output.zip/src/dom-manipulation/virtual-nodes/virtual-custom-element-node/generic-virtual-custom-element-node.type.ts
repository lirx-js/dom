import { VirtualCustomElementNode } from './virtual-custom-element-node.class';

// export type IGenericGenericVirtualCustomElementNode = VirtualCustomElementNode<HTMLElement, ITypedSourcesMapEntriesTuple>;
// export type IGenericGenericVirtualCustomElementNode = VirtualCustomElementNode<IVirtualCustomElementNodeConfig>;
export type IGenericVirtualCustomElementNode = VirtualCustomElementNode<any>;
