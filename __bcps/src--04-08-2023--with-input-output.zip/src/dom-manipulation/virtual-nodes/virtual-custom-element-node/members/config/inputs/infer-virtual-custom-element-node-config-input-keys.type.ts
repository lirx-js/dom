import { IVirtualCustomElementNodeConfig } from '../virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeInputMapKeys } from '../../inputs/virtual-custom-element-node-input-map.class';
import { InferVirtualCustomElementNodeConfigInputs } from './infer-virtual-custom-element-node-config-inputs.type';

export type InferVirtualCustomElementNodeConfigInputKeys<GConfig extends IVirtualCustomElementNodeConfig> =
  InferVirtualCustomElementNodeInputMapKeys<InferVirtualCustomElementNodeConfigInputs<GConfig>>;

