import { IVirtualCustomElementNodeConfig } from '../virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeConfigInputKeys } from './infer-virtual-custom-element-node-config-input-keys.type';
import { InferVirtualCustomElementNodeInputMapValueFromKey } from '../../inputs/virtual-custom-element-node-input-map.class';
import { InferVirtualCustomElementNodeConfigInputs } from './infer-virtual-custom-element-node-config-inputs.type';

export type InferVirtualCustomElementNodeConfigInputValueFromKey<GConfig extends IVirtualCustomElementNodeConfig, GKey extends InferVirtualCustomElementNodeConfigInputKeys<GConfig>> =
  InferVirtualCustomElementNodeInputMapValueFromKey<InferVirtualCustomElementNodeConfigInputs<GConfig>, GKey>;
