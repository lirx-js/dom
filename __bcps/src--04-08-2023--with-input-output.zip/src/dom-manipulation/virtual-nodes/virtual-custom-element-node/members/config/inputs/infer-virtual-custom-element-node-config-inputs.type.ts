import { IVirtualCustomElementNodeConfig } from '../virtual-custom-element-node-config.type';
import { IVirtualCustomElementNodeConfigInputs } from './virtual-custom-element-node-config-inputs.type';

export type InferVirtualCustomElementNodeConfigInputs<GConfig extends IVirtualCustomElementNodeConfig> =
  GConfig['inputs'] extends IVirtualCustomElementNodeConfigInputs
    ? GConfig['inputs']
    : never;
