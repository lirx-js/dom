import { IGenericVirtualCustomElementInput } from '../../inputs/virtual-custom-element-node-input-map.class';

export type IVirtualCustomElementNodeConfigInputs = IGenericVirtualCustomElementInput;

