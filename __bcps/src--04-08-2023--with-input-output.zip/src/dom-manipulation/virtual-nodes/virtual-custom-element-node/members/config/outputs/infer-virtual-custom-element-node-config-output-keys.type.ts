import { IVirtualCustomElementNodeConfig } from '../virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeOutputMapKeys } from '../../outputs/virtual-custom-element-node-output-map.class';
import { InferVirtualCustomElementNodeConfigOutputs } from './infer-virtual-custom-element-node-config-outputs.type';

export type InferVirtualCustomElementNodeConfigOutputKeys<GConfig extends IVirtualCustomElementNodeConfig> =
  InferVirtualCustomElementNodeOutputMapKeys<InferVirtualCustomElementNodeConfigOutputs<GConfig>>;

