import { IVirtualCustomElementNodeConfig } from '../virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeConfigOutputKeys } from './infer-virtual-custom-element-node-config-output-keys.type';
import { InferVirtualCustomElementNodeOutputMapValueFromKey } from '../../outputs/virtual-custom-element-node-output-map.class';
import { InferVirtualCustomElementNodeConfigOutputs } from './infer-virtual-custom-element-node-config-outputs.type';

export type InferVirtualCustomElementNodeConfigOutputValueFromKey<GConfig extends IVirtualCustomElementNodeConfig, GKey extends InferVirtualCustomElementNodeConfigOutputKeys<GConfig>> =
  InferVirtualCustomElementNodeOutputMapValueFromKey<InferVirtualCustomElementNodeConfigOutputs<GConfig>, GKey>;
