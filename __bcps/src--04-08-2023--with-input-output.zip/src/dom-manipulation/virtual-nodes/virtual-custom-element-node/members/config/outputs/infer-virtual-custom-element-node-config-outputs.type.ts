import { IVirtualCustomElementNodeConfig } from '../virtual-custom-element-node-config.type';
import { IVirtualCustomElementNodeConfigOutputs } from './virtual-custom-element-node-config-outputs.type';

export type InferVirtualCustomElementNodeConfigOutputs<GConfig extends IVirtualCustomElementNodeConfig> =
  GConfig['outputs'] extends IVirtualCustomElementNodeConfigOutputs
    ? GConfig['outputs']
    : never;
