import { IGenericVirtualCustomElementOutput } from '../../outputs/virtual-custom-element-node-output-map.class';

export type IVirtualCustomElementNodeConfigOutputs = IGenericVirtualCustomElementOutput;

