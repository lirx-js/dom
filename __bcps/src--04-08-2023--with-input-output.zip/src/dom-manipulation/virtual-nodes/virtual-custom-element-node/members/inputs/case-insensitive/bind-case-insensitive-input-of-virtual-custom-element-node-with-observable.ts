import { IObservable } from '@lirx/core';
import { IUnsubscribe } from '@lirx/utils';
import { VirtualCustomElementNode } from '../../../virtual-custom-element-node.class';

import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  getCaseInsensitiveInputKeyOfVirtualCustomElementNode,
} from './get-case-insensitive-input-key-of-virtual-custom-element-node';
import {
  InferCaseInsensitiveInputKeyOfVirtualCustomElementNode,
} from './infer-case-insensitive-input-key-of-virtual-custom-element-node.type';
import {
  InferVirtualCustomElementNodeInputValueFromCaseInsensitiveKey,
} from './infer-virtual-custom-element-node-input-value-from-case-insensitive-key.type';
import {
  InferVirtualCustomElementNodeConfigInputValueFromKey
} from '../../config/inputs/infer-virtual-custom-element-node-config-input-value-from-key.type';

export function bindCaseInsensitiveInputOfVirtualCustomElementNodeWithObservable<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string>(
  node: VirtualCustomElementNode<GConfig>,
  key: GCaseInsensitiveKey,
  value$: IObservable<InferVirtualCustomElementNodeInputValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>>,
): IUnsubscribe {
  type GKey = InferCaseInsensitiveInputKeyOfVirtualCustomElementNode<GConfig, GCaseInsensitiveKey>;
  return node.bindInputWithObservable<GKey>(
    getCaseInsensitiveInputKeyOfVirtualCustomElementNode<GConfig, GCaseInsensitiveKey>(node, key),
    value$ as IObservable<InferVirtualCustomElementNodeConfigInputValueFromKey<GConfig, GKey>>,
  );
}
