import { CaseInsensitiveKeyMap, IGenericCaseInsensitiveKeyMap } from '../../../../../../misc/classes/case-insensitive-key-map.class';
import { VirtualCustomElementNode } from '../../../virtual-custom-element-node.class';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  InferVirtualCustomElementNodeInputMapKeys,
  IGenericVirtualCustomElementNodeInputMap, IGenericVirtualCustomElementInput, VirtualCustomElementNodeInputMap,
} from '../virtual-custom-element-node-input-map.class';
import { InferVirtualCustomElementNodeConfigInputs } from '../../config/inputs/infer-virtual-custom-element-node-config-inputs.type';

export function getCaseInsensitiveInputKeyMapOfVirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig>(
  node: VirtualCustomElementNode<GConfig>,
): CaseInsensitiveKeyMap<InferVirtualCustomElementNodeInputMapKeys<InferVirtualCustomElementNodeConfigInputs<GConfig>>> {
  return getCaseInsensitiveInputKeyMapOfVirtualCustomElementNodeInputs<InferVirtualCustomElementNodeConfigInputs<GConfig>>(node.inputs);
}

const CACHE = new WeakMap<IGenericVirtualCustomElementNodeInputMap, IGenericCaseInsensitiveKeyMap>();

function getCaseInsensitiveInputKeyMapOfVirtualCustomElementNodeInputs<GInput extends IGenericVirtualCustomElementInput>(
  inputs: VirtualCustomElementNodeInputMap<GInput>,
): CaseInsensitiveKeyMap<InferVirtualCustomElementNodeInputMapKeys<GInput>> {
  let map: CaseInsensitiveKeyMap<InferVirtualCustomElementNodeInputMapKeys<GInput>> | undefined = CACHE.get(inputs);
  if (map === void 0) {
    map = createCaseInsensitiveInputKeyMapOfVirtualCustomElementNodeInputs<GInput>(inputs);
    CACHE.set(inputs, map);
  }
  return map;
}

function createCaseInsensitiveInputKeyMapOfVirtualCustomElementNodeInputs<GInput extends IGenericVirtualCustomElementInput>(
  inputs: VirtualCustomElementNodeInputMap<GInput>,
): CaseInsensitiveKeyMap<InferVirtualCustomElementNodeInputMapKeys<GInput>> {
  return new CaseInsensitiveKeyMap<InferVirtualCustomElementNodeInputMapKeys<GInput>>(
    inputs.keys(),
  );
}
