import { VirtualCustomElementNode } from '../../../virtual-custom-element-node.class';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  getCaseInsensitiveInputKeyMapOfVirtualCustomElementNode,
} from './get-case-insensitive-input-key-map-of-virtual-custom-element-node';
import {
  InferCaseInsensitiveInputKeyOfVirtualCustomElementNode
} from './infer-case-insensitive-input-key-of-virtual-custom-element-node.type';


export function getCaseInsensitiveInputKeyOfVirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string>(
  node: VirtualCustomElementNode<GConfig>,
  key: GCaseInsensitiveKey,
): InferCaseInsensitiveInputKeyOfVirtualCustomElementNode<GConfig, GCaseInsensitiveKey> {
  return getCaseInsensitiveInputKeyMapOfVirtualCustomElementNode<GConfig>(node).get<GCaseInsensitiveKey>(key);
}
