import { InferCaseInsensitiveKeyMapGetReturn } from '../../../../../../misc/classes/case-insensitive-key-map.class';
import { InferVirtualCustomElementNodeConfigInputs } from '../../config/inputs/infer-virtual-custom-element-node-config-inputs.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeInputMapKeys } from '../virtual-custom-element-node-input-map.class';

export type InferCaseInsensitiveInputKeyOfVirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string> =
  InferCaseInsensitiveKeyMapGetReturn<InferVirtualCustomElementNodeInputMapKeys<InferVirtualCustomElementNodeConfigInputs<GConfig>>, GCaseInsensitiveKey>;
