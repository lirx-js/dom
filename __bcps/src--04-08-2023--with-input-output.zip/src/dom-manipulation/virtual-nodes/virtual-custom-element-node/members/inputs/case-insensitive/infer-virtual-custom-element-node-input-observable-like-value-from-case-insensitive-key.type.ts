import { IObservableLike, INotAnObservable } from '@lirx/core';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  InferVirtualCustomElementNodeInputValueFromCaseInsensitiveKey,
} from './infer-virtual-custom-element-node-input-value-from-case-insensitive-key.type';


export type InferVirtualCustomElementNodeInputObservableLikeValueFromCaseInsensitiveKey<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string> =
  InferVirtualCustomElementNodeInputValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey> extends INotAnObservable<InferVirtualCustomElementNodeInputValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>>
    ? IObservableLike<InferVirtualCustomElementNodeInputValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>>
    : never;
