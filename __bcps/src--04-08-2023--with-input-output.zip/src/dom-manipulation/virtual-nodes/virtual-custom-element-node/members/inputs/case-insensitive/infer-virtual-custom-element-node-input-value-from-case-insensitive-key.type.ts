import {
  InferVirtualCustomElementNodeConfigInputs,
} from '../../config/inputs/infer-virtual-custom-element-node-config-inputs.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { IGenericVirtualCustomElementInput } from '../virtual-custom-element-node-input-map.class';


export type InferVirtualCustomElementNodeInputValueFromInputAndCaseInsensitiveKey<GInput extends IGenericVirtualCustomElementInput, GCaseInsensitiveKey extends string> =
  GInput extends [Lowercase<GCaseInsensitiveKey>, infer GValue]
    ? GValue
    : never;

export type InferVirtualCustomElementNodeInputValueFromCaseInsensitiveKey<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string> =
  InferVirtualCustomElementNodeInputValueFromInputAndCaseInsensitiveKey<InferVirtualCustomElementNodeConfigInputs<GConfig>, GCaseInsensitiveKey>;

