import { IObservable, IObserver, IMulticastReplayLastSource, createMulticastReplayLastSource } from '@lirx/core';
import {
  InferTypedMapKeys,
  InferTypedMapValueFromKey,
  ITypedMapEntry,
  TypedMap,
  InferTypedMapHasValueFromKey,
  InferTypedMapValues,
} from '@lirx/utils';

/** TYPES **/

// ENTRY

export type IVirtualCustomElementInput<GKey extends string, GValue> = ITypedMapEntry<GKey, GValue>;

export type IGenericVirtualCustomElementInput = IVirtualCustomElementInput<any, any>;

// KEYS AND VALUES
export type InferVirtualCustomElementNodeInputMapKeys<GInput extends IGenericVirtualCustomElementInput> = InferTypedMapKeys<GInput>;

export type InferVirtualCustomElementNodeInputMapValues<GInput extends IGenericVirtualCustomElementInput> = InferTypedMapValues<GInput>;

export type InferVirtualCustomElementNodeInputMapHasValueFromKey<GInput extends IGenericVirtualCustomElementInput, GKey extends string> =
  InferTypedMapHasValueFromKey<GInput, GKey>;

export type InferVirtualCustomElementNodeInputMapValueFromKey<GInput extends IGenericVirtualCustomElementInput, GKey extends InferVirtualCustomElementNodeInputMapKeys<GInput>> =
  InferTypedMapValueFromKey<GInput, GKey>;

// INPUT
export type IVirtualCustomElementNodeInputMapInputEntry<GKey extends string, GValue> =
  | readonly [key: GKey, value?: GValue]
  | GKey
  ;

export type InferVirtualCustomElementNodeInputMapInputEntry<GInput extends IGenericVirtualCustomElementInput> =
  GInput extends readonly [infer GKey, infer GValue]
    ? (
      GKey extends string
        ? IVirtualCustomElementNodeInputMapInputEntry<GKey, GValue>
        : never
      )
    : never
  ;

export type InferVirtualCustomElementNodeInputMapInput<GInput extends IGenericVirtualCustomElementInput> = Iterable<InferVirtualCustomElementNodeInputMapInputEntry<GInput>>;

// MAP
export type InferVirtualCustomElementNodeInputMapEntry<GInput extends IGenericVirtualCustomElementInput> =
  GInput extends readonly [infer GKey, infer GValue]
    ? readonly [GKey, IMulticastReplayLastSource<GValue>]
    : never;

// GET

export interface IVirtualCustomElementNodeInputMapGetOptions {

}

/** CLASS **/

export class VirtualCustomElementNodeInputMap<GInput extends IGenericVirtualCustomElementInput> {
  readonly #map: TypedMap<InferVirtualCustomElementNodeInputMapEntry<GInput>>;

  constructor(
    input: InferVirtualCustomElementNodeInputMapInput<GInput>,
  ) {
    this.#map = new TypedMap<InferVirtualCustomElementNodeInputMapEntry<GInput>>(
      Array.from(input, (entry: InferVirtualCustomElementNodeInputMapInputEntry<GInput>): InferVirtualCustomElementNodeInputMapEntry<GInput> => {
        let key: string;
        let source: IMulticastReplayLastSource<unknown>;

        if (typeof entry === 'string') {
          key = entry;
          source = createMulticastReplayLastSource<unknown>();
        } else {
          key = entry[0];

          if (entry.length === 1) {
            source = createMulticastReplayLastSource<unknown>();
          } else {
            source = createMulticastReplayLastSource<unknown>(entry[1]);
          }
        }

        return [
          key,
          source,
        ] as unknown as InferVirtualCustomElementNodeInputMapEntry<GInput>;
      }),
    );
  }

  has<GKey extends string>(
    key: GKey,
  ): InferVirtualCustomElementNodeInputMapHasValueFromKey<GInput, GKey> {
    return this.#map.has<GKey>(key) as any;
  }

  source<GKey extends InferVirtualCustomElementNodeInputMapKeys<GInput>>(
    key: GKey,
  ): IMulticastReplayLastSource<InferVirtualCustomElementNodeInputMapValueFromKey<GInput, GKey>> {
    return this.#map.get<GKey>(key);
  }

  get$<GKey extends InferVirtualCustomElementNodeInputMapKeys<GInput>>(
    key: GKey,
  ): IObservable<InferVirtualCustomElementNodeInputMapValueFromKey<GInput, GKey>> {
    return this.source<GKey>(key).subscribe;
  }

  get<GKey extends InferVirtualCustomElementNodeInputMapKeys<GInput>>(
    key: GKey,
    unsafe?: false,
  ): InferVirtualCustomElementNodeInputMapValueFromKey<GInput, GKey>;
  get<GKey extends InferVirtualCustomElementNodeInputMapKeys<GInput>>(
    key: GKey,
    unsafe: true,
  ): InferVirtualCustomElementNodeInputMapValueFromKey<GInput, GKey> | undefined;
  get<GKey extends InferVirtualCustomElementNodeInputMapKeys<GInput>>(
    key: GKey,
    unsafe?: boolean,
  ): InferVirtualCustomElementNodeInputMapValueFromKey<GInput, GKey> | undefined {
    return this.source<GKey>(key).getValue(unsafe as any);
    // return readObservableValue(this.get$<GKey>(key), (): never => {
    //   throw new Error(`Unable to read: ${key}`);
    // });
  }

  $set<GKey extends InferVirtualCustomElementNodeInputMapKeys<GInput>>(
    key: GKey,
  ): IObserver<InferVirtualCustomElementNodeInputMapValueFromKey<GInput, GKey>> {
    return this.source<GKey>(key).emit;
  }

  set<GKey extends InferVirtualCustomElementNodeInputMapKeys<GInput>>(
    key: GKey,
    value: InferVirtualCustomElementNodeInputMapValueFromKey<GInput, GKey>,
  ): void {
    this.$set<GKey>(key)(value);
  }

  keys(): IterableIterator<InferVirtualCustomElementNodeInputMapKeys<GInput>> {
    return this.#map.keys();
  }
}

export type IGenericVirtualCustomElementNodeInputMap = VirtualCustomElementNodeInputMap<any>

/*---------------------*/

/*---------------------*/

// type A =
//   | ['A', string]
//   | ['b', boolean]
// ;
//
// const a = new VirtualCustomElementNodeInputMap<A>([
//   ['A'],
//   'b',
// ]);
//
// const b = a.get$('A');
