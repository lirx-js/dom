import {
  InferVirtualCustomElementNodeConfigInputs,
} from '../../config/inputs/infer-virtual-custom-element-node-config-inputs.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeOptionsInputs } from './infer-virtual-custom-element-node-options-inputs.type';


export type InferVirtualCustomElementNodeOptionsInputsInterface<GConfig extends IVirtualCustomElementNodeConfig> =
  InferVirtualCustomElementNodeConfigInputs<GConfig> extends never
    ? {
      inputs?: Iterable<never> | readonly [];
    }
    : {
      inputs: InferVirtualCustomElementNodeOptionsInputs<GConfig>,
    }
  ;

