import { InferVirtualCustomElementNodeConfigInputs } from '../../config/inputs/infer-virtual-custom-element-node-config-inputs.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeInputMapInput } from '../../inputs/virtual-custom-element-node-input-map.class';

export type InferVirtualCustomElementNodeOptionsInputs<GConfig extends IVirtualCustomElementNodeConfig> =
  InferVirtualCustomElementNodeInputMapInput<InferVirtualCustomElementNodeConfigInputs<GConfig>>
  ;
