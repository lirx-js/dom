import {
  InferVirtualCustomElementNodeConfigOutputs,
} from '../../config/outputs/infer-virtual-custom-element-node-config-outputs.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeOptionsOutputs } from './infer-virtual-custom-element-node-options-outputs.type';


export type InferVirtualCustomElementNodeOptionsOutputsInterface<GConfig extends IVirtualCustomElementNodeConfig> =
  InferVirtualCustomElementNodeConfigOutputs<GConfig> extends never
    ? {
      outputs?: Iterable<never> | readonly [];
    }
    : {
      outputs: InferVirtualCustomElementNodeOptionsOutputs<GConfig>,
    }
  ;

