import { InferVirtualCustomElementNodeConfigOutputs } from '../../config/outputs/infer-virtual-custom-element-node-config-outputs.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeOutputMapInput } from '../../outputs/virtual-custom-element-node-output-map.class';

export type InferVirtualCustomElementNodeOptionsOutputs<GConfig extends IVirtualCustomElementNodeConfig> =
  InferVirtualCustomElementNodeOutputMapInput<InferVirtualCustomElementNodeConfigOutputs<GConfig>>
  ;
