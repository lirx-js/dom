import { IObservable, IObserver } from '@lirx/core';
import { IUnsubscribe } from '@lirx/utils';
import { VirtualCustomElementNode } from '../../../virtual-custom-element-node.class';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  InferVirtualCustomElementNodeOutputValueFromCaseInsensitiveKey
} from './infer-virtual-custom-element-node-output-value-from-case-insensitive-key.type';
import {
  InferCaseInsensitiveOutputKeyOfVirtualCustomElementNode
} from './infer-case-insensitive-output-key-of-virtual-custom-element-node.type';
import { getCaseInsensitiveOutputKeyOfVirtualCustomElementNode } from './get-case-insensitive-output-key-of-virtual-custom-element-node';
import {
  InferVirtualCustomElementNodeConfigOutputValueFromKey
} from '../../config/outputs/infer-virtual-custom-element-node-config-output-value-from-key.type';

export function bindCaseInsensitiveOutputOfVirtualCustomElementNodeWithObservableOfObserver<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string>(
  node: VirtualCustomElementNode<GConfig>,
  key: GCaseInsensitiveKey,
  $value: IObservable<IObserver<InferVirtualCustomElementNodeOutputValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>>>,
): IUnsubscribe {
  type GKey = InferCaseInsensitiveOutputKeyOfVirtualCustomElementNode<GConfig, GCaseInsensitiveKey>;
  return node.bindOutputWithObservableOfObserver<GKey>(
    getCaseInsensitiveOutputKeyOfVirtualCustomElementNode<GConfig, GCaseInsensitiveKey>(node, key),
    $value as IObservable<IObserver<InferVirtualCustomElementNodeConfigOutputValueFromKey<GConfig, GKey>>>,
  );
}
