import { CaseInsensitiveKeyMap, IGenericCaseInsensitiveKeyMap } from '../../../../../../misc/classes/case-insensitive-key-map.class';
import { VirtualCustomElementNode } from '../../../virtual-custom-element-node.class';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  InferVirtualCustomElementNodeOutputMapKeys,
  IGenericVirtualCustomElementNodeOutputMap, IGenericVirtualCustomElementOutput, VirtualCustomElementNodeOutputMap,
} from '../virtual-custom-element-node-output-map.class';
import { InferVirtualCustomElementNodeConfigOutputs } from '../../config/outputs/infer-virtual-custom-element-node-config-outputs.type';

export function getCaseInsensitiveOutputKeyMapOfVirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig>(
  node: VirtualCustomElementNode<GConfig>,
): CaseInsensitiveKeyMap<InferVirtualCustomElementNodeOutputMapKeys<InferVirtualCustomElementNodeConfigOutputs<GConfig>>> {
  return getCaseInsensitiveOutputKeyMapOfVirtualCustomElementNodeOutputs<InferVirtualCustomElementNodeConfigOutputs<GConfig>>(node.outputs);
}

const CACHE = new WeakMap<IGenericVirtualCustomElementNodeOutputMap, IGenericCaseInsensitiveKeyMap>();

function getCaseInsensitiveOutputKeyMapOfVirtualCustomElementNodeOutputs<GOutput extends IGenericVirtualCustomElementOutput>(
  outputs: VirtualCustomElementNodeOutputMap<GOutput>,
): CaseInsensitiveKeyMap<InferVirtualCustomElementNodeOutputMapKeys<GOutput>> {
  let map: CaseInsensitiveKeyMap<InferVirtualCustomElementNodeOutputMapKeys<GOutput>> | undefined = CACHE.get(outputs);
  if (map === void 0) {
    map = createCaseInsensitiveOutputKeyMapOfVirtualCustomElementNodeOutputs<GOutput>(outputs);
    CACHE.set(outputs, map);
  }
  return map;
}

function createCaseInsensitiveOutputKeyMapOfVirtualCustomElementNodeOutputs<GOutput extends IGenericVirtualCustomElementOutput>(
  outputs: VirtualCustomElementNodeOutputMap<GOutput>,
): CaseInsensitiveKeyMap<InferVirtualCustomElementNodeOutputMapKeys<GOutput>> {
  return new CaseInsensitiveKeyMap<InferVirtualCustomElementNodeOutputMapKeys<GOutput>>(
    outputs.keys(),
  );
}
