import { VirtualCustomElementNode } from '../../../virtual-custom-element-node.class';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  getCaseInsensitiveOutputKeyMapOfVirtualCustomElementNode,
} from './get-case-insensitive-output-key-map-of-virtual-custom-element-node';
import {
  InferCaseInsensitiveOutputKeyOfVirtualCustomElementNode
} from './infer-case-insensitive-output-key-of-virtual-custom-element-node.type';


export function getCaseInsensitiveOutputKeyOfVirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string>(
  node: VirtualCustomElementNode<GConfig>,
  key: GCaseInsensitiveKey,
): InferCaseInsensitiveOutputKeyOfVirtualCustomElementNode<GConfig, GCaseInsensitiveKey> {
  return getCaseInsensitiveOutputKeyMapOfVirtualCustomElementNode<GConfig>(node).get<GCaseInsensitiveKey>(key);
}
