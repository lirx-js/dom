import { InferCaseInsensitiveKeyMapGetReturn } from '../../../../../../misc/classes/case-insensitive-key-map.class';
import { InferVirtualCustomElementNodeConfigOutputs } from '../../config/outputs/infer-virtual-custom-element-node-config-outputs.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { InferVirtualCustomElementNodeOutputMapKeys } from '../virtual-custom-element-node-output-map.class';

export type InferCaseInsensitiveOutputKeyOfVirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string> =
  InferCaseInsensitiveKeyMapGetReturn<InferVirtualCustomElementNodeOutputMapKeys<InferVirtualCustomElementNodeConfigOutputs<GConfig>>, GCaseInsensitiveKey>;
