import { IObservableLike, INotAnObservable } from '@lirx/core';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import {
  InferVirtualCustomElementNodeOutputValueFromCaseInsensitiveKey
} from './infer-virtual-custom-element-node-output-value-from-case-insensitive-key.type';

export type InferVirtualCustomElementNodeOutputObservableLikeValueFromCaseInsensitiveKey<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string> =
  InferVirtualCustomElementNodeOutputValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey> extends INotAnObservable<InferVirtualCustomElementNodeOutputValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>>
    ? IObservableLike<InferVirtualCustomElementNodeOutputValueFromCaseInsensitiveKey<GConfig, GCaseInsensitiveKey>>
    : never;
