import {
  InferVirtualCustomElementNodeConfigOutputs,
} from '../../config/outputs/infer-virtual-custom-element-node-config-outputs.type';
import { IVirtualCustomElementNodeConfig } from '../../config/virtual-custom-element-node-config.type';
import { IGenericVirtualCustomElementOutput } from '../virtual-custom-element-node-output-map.class';


export type InferVirtualCustomElementNodeOutputValueFromOutputAndCaseInsensitiveKey<GOutput extends IGenericVirtualCustomElementOutput, GCaseInsensitiveKey extends string> =
  GOutput extends [Lowercase<GCaseInsensitiveKey>, infer GValue]
    ? GValue
    : never;

export type InferVirtualCustomElementNodeOutputValueFromCaseInsensitiveKey<GConfig extends IVirtualCustomElementNodeConfig, GCaseInsensitiveKey extends string> =
  InferVirtualCustomElementNodeOutputValueFromOutputAndCaseInsensitiveKey<InferVirtualCustomElementNodeConfigOutputs<GConfig>, GCaseInsensitiveKey>;

