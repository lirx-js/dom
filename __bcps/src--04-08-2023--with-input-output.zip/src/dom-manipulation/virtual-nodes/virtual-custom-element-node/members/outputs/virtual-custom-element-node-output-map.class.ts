import { IObservable, IObserver, IMulticastSource, createMulticastSource } from '@lirx/core';
import {
  InferTypedMapKeys,
  InferTypedMapValueFromKey,
  ITypedMapEntry,
  TypedMap,
  InferTypedMapHasValueFromKey,
  InferTypedMapValues,
} from '@lirx/utils';

/** TYPES **/

// ENTRY

export type IVirtualCustomElementOutput<GKey extends string, GValue> = ITypedMapEntry<GKey, GValue>;

export type IGenericVirtualCustomElementOutput = IVirtualCustomElementOutput<any, any>;

// KEYS AND VALUES
export type InferVirtualCustomElementNodeOutputMapKeys<GOutput extends IGenericVirtualCustomElementOutput> = InferTypedMapKeys<GOutput>;

export type InferVirtualCustomElementNodeOutputMapValues<GOutput extends IGenericVirtualCustomElementOutput> = InferTypedMapValues<GOutput>;

export type InferVirtualCustomElementNodeOutputMapHasValueFromKey<GOutput extends IGenericVirtualCustomElementOutput, GKey extends string> =
  InferTypedMapHasValueFromKey<GOutput, GKey>;

export type InferVirtualCustomElementNodeOutputMapValueFromKey<GOutput extends IGenericVirtualCustomElementOutput, GKey extends InferVirtualCustomElementNodeOutputMapKeys<GOutput>> =
  InferTypedMapValueFromKey<GOutput, GKey>;

// INPUT
export type IVirtualCustomElementNodeOutputMapInputEntry<GKey extends string, GValue> =
  | readonly [key: GKey]
  | GKey
  ;

export type InferVirtualCustomElementNodeOutputMapInputEntry<GOutput extends IGenericVirtualCustomElementOutput> =
  GOutput extends readonly [infer GKey, infer GValue]
    ? (
      GKey extends string
        ? IVirtualCustomElementNodeOutputMapInputEntry<GKey, GValue>
        : never
      )
    : never
  ;

export type InferVirtualCustomElementNodeOutputMapInput<GOutput extends IGenericVirtualCustomElementOutput> = Iterable<InferVirtualCustomElementNodeOutputMapInputEntry<GOutput>>;

// MAP
export type InferVirtualCustomElementNodeOutputMapEntry<GOutput extends IGenericVirtualCustomElementOutput> =
  GOutput extends readonly [infer GKey, infer GValue]
    ? readonly [GKey, IMulticastSource<GValue>]
    : never;

/** CLASS **/

export class VirtualCustomElementNodeOutputMap<GOutput extends IGenericVirtualCustomElementOutput> {
  readonly #map: TypedMap<InferVirtualCustomElementNodeOutputMapEntry<GOutput>>;

  constructor(
    input: InferVirtualCustomElementNodeOutputMapInput<GOutput>,
  ) {
    this.#map = new TypedMap<InferVirtualCustomElementNodeOutputMapEntry<GOutput>>(
      Array.from(input, (entry: InferVirtualCustomElementNodeOutputMapInputEntry<GOutput>): InferVirtualCustomElementNodeOutputMapEntry<GOutput> => {
        let key: string;
        let source: IMulticastSource<unknown>;

        if (typeof entry === 'string') {
          key = entry;
          source = createMulticastSource<unknown>();
        } else {
          key = entry[0];
          source = createMulticastSource<unknown>();
        }

        return [
          key,
          source,
        ] as unknown as InferVirtualCustomElementNodeOutputMapEntry<GOutput>;
      }),
    );
  }

  has<GKey extends string>(
    key: GKey,
  ): InferVirtualCustomElementNodeOutputMapHasValueFromKey<GOutput, GKey> {
    return this.#map.has<GKey>(key) as any;
  }

  source<GKey extends InferVirtualCustomElementNodeOutputMapKeys<GOutput>>(
    key: GKey,
  ): IMulticastSource<InferVirtualCustomElementNodeOutputMapValueFromKey<GOutput, GKey>> {
    return this.#map.get<GKey>(key);
  }

  get$<GKey extends InferVirtualCustomElementNodeOutputMapKeys<GOutput>>(
    key: GKey,
  ): IObservable<InferVirtualCustomElementNodeOutputMapValueFromKey<GOutput, GKey>> {
    return this.source<GKey>(key).subscribe;
  }

  $set<GKey extends InferVirtualCustomElementNodeOutputMapKeys<GOutput>>(
    key: GKey,
  ): IObserver<InferVirtualCustomElementNodeOutputMapValueFromKey<GOutput, GKey>> {
    return this.source<GKey>(key).emit;
  }

  keys(): IterableIterator<InferVirtualCustomElementNodeOutputMapKeys<GOutput>> {
    return this.#map.keys();
  }
}

export type IGenericVirtualCustomElementNodeOutputMap = VirtualCustomElementNodeOutputMap<any>

/*---------------------*/

/*---------------------*/

// type A =
//   | ['A', string]
//   | ['b', boolean]
// ;
//
// const a = new VirtualCustomElementNodeOutputMap<A>([
//   ['A'],
//   'b',
// ]);
//
// const b = a.get$('A');
