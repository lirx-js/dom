import { IVirtualCustomElementNodeSlotTemplate } from './virtual-custom-element-node-slot-template.type';

export type IVirtualCustomElementNodeSlotsMap = ReadonlyMap<string | '*', IVirtualCustomElementNodeSlotTemplate<object>>;
