import { IObservable, IObserver, subscribeToObservableUsingAnObservableOfObserver } from '@lirx/core';
import { IUnsubscribe } from '@lirx/utils';
import { HTML_NAMESPACE_URI_CONSTANT } from '../../misc/namespace-uri/html-namespace-uri.constant';
import { VirtualReactiveElementNode } from '../virtual-reactive-element-node/virtual-reactive-element-node.class';
import { InferVirtualCustomElementNodeConfigElement } from './members/config/infer-virtual-custom-element-node-config-element.type';
import { IVirtualCustomElementNodeConfig } from './members/config/virtual-custom-element-node-config.type';
import { IVirtualCustomElementNodeOptions } from './members/options/virtual-custom-element-node-options.type';
import { IVirtualCustomElementNodeSlotsMap } from './members/slots/virtual-custom-element-node-slots-map.type';
import { InferVirtualCustomElementNodeConfigInputs } from './members/config/inputs/infer-virtual-custom-element-node-config-inputs.type';
import {
  InferVirtualCustomElementNodeConfigInputKeys,
} from './members/config/inputs/infer-virtual-custom-element-node-config-input-keys.type';
import { VirtualCustomElementNodeInputMap } from './members/inputs/virtual-custom-element-node-input-map.class';
import { VirtualCustomElementNodeOutputMap } from './members/outputs/virtual-custom-element-node-output-map.class';
import {
  InferVirtualCustomElementNodeConfigInputValueFromKey,
} from './members/config/inputs/infer-virtual-custom-element-node-config-input-value-from-key.type';
import { InferVirtualCustomElementNodeConfigOutputs } from './members/config/outputs/infer-virtual-custom-element-node-config-outputs.type';
import {
  InferVirtualCustomElementNodeConfigOutputKeys,
} from './members/config/outputs/infer-virtual-custom-element-node-config-output-keys.type';
import {
  InferVirtualCustomElementNodeConfigOutputValueFromKey,
} from './members/config/outputs/infer-virtual-custom-element-node-config-output-value-from-key.type';

/**
 * Represents an instance of a Component.
 * It has:
 * - a name
 * - some slots
 * - and some 'properties'
 */
export class VirtualCustomElementNode<GConfig extends IVirtualCustomElementNodeConfig> extends VirtualReactiveElementNode<InferVirtualCustomElementNodeConfigElement<GConfig>> {
  readonly #name: string;
  readonly #extends: string | undefined;
  readonly #slots: IVirtualCustomElementNodeSlotsMap;

  readonly #inputs: VirtualCustomElementNodeInputMap<InferVirtualCustomElementNodeConfigInputs<GConfig>>;
  readonly #outputs: VirtualCustomElementNodeOutputMap<InferVirtualCustomElementNodeConfigOutputs<GConfig>>;

  constructor(
    {
      name,
      extends: _extends,
      namespaceURI = HTML_NAMESPACE_URI_CONSTANT,
      slots,
      inputs = [],
      outputs = [],
    }: IVirtualCustomElementNodeOptions<GConfig>,
  ) {
    super(
      namespaceURI,
      (_extends === void 0)
        ? name
        : _extends,
    );
    this.#name = name;
    this.#extends = _extends;
    this.#slots = slots;
    this.#inputs = new VirtualCustomElementNodeInputMap<InferVirtualCustomElementNodeConfigInputs<GConfig>>(inputs);
    this.#outputs = new VirtualCustomElementNodeOutputMap<InferVirtualCustomElementNodeConfigOutputs<GConfig>>(outputs);

    if (_extends !== void 0) {
      this.setAttribute('is', name);
    }
  }

  get name(): string {
    return this.#name;
  }

  get extends(): string | undefined {
    return this.#extends;
  }

  get slots(): IVirtualCustomElementNodeSlotsMap {
    return this.#slots;
  }

  get inputs(): VirtualCustomElementNodeInputMap<InferVirtualCustomElementNodeConfigInputs<GConfig>> {
    return this.#inputs;
  }

  get outputs(): VirtualCustomElementNodeOutputMap<InferVirtualCustomElementNodeConfigOutputs<GConfig>> {
    return this.#outputs;
  }

  bindInputWithObservable<GKey extends InferVirtualCustomElementNodeConfigInputKeys<GConfig>>(
    key: GKey,
    value$: IObservable<InferVirtualCustomElementNodeConfigInputValueFromKey<GConfig, GKey>>,
  ): IUnsubscribe {
    return this.onConnected((): IUnsubscribe => {
      return value$(this.inputs.$set<GKey>(key));
    });
  }

  bindOutputWithObserver<GKey extends InferVirtualCustomElementNodeConfigOutputKeys<GConfig>>(
    key: GKey,
    $value: IObserver<InferVirtualCustomElementNodeConfigOutputValueFromKey<GConfig, GKey>>,
  ): IUnsubscribe {
    return this.onConnected((): IUnsubscribe => {
      return this.outputs.get$<GKey>(key)($value);
    });
  }

  bindOutputWithObservableOfObserver<GKey extends InferVirtualCustomElementNodeConfigOutputKeys<GConfig>>(
    key: GKey,
    $value: IObservable<IObserver<InferVirtualCustomElementNodeConfigOutputValueFromKey<GConfig, GKey>>>,
  ): IUnsubscribe {

    return this.onConnected((): IUnsubscribe => {
      return subscribeToObservableUsingAnObservableOfObserver<InferVirtualCustomElementNodeConfigOutputValueFromKey<GConfig, GKey>>(
        this.outputs.get$<GKey>(key),
        $value,
      );
    });
  }
}

/*-------------------*/

/*-------------------*/

// interface TestConfig {
//   element: HTMLButtonElement;
//   inputs:
//     | ['i-a', boolean]
//     | ['o-a', number]
//     | ['o-b', string]
//   ,
// }
//
// const a = new VirtualCustomElementNode<TestConfig>({
//   name: 'test',
//   slots: new Map(),
//   inputs: [
//     ['i-a', true],
//     'o-b',
//     ['o-a'],
//   ],
// });
//
//
// a.properties.get('i-a');
// a.properties.set('o-a', 4);
//
// a.setReactiveInput('i-a', single(true))
// a.setReactiveOutput('i-a', (value: boolean) => {})
// a.setReactiveOutput('o-a', (value: number) => {})
