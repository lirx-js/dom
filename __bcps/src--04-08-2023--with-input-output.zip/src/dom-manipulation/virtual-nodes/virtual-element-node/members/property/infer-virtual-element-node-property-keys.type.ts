export type InferVirtualElementNodePropertyKeys<GElementNode extends Element> = keyof GElementNode;
