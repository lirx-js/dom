export const DEFAULT_SLOT_NAME_CONSTANT = '*';
