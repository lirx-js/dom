export const RX_CONTAINER_TAG_NAME: string = 'rx-container';
