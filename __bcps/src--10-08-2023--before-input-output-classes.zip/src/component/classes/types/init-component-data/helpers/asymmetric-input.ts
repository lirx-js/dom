import { IMulticastReplayLastSource, IObserver, IMapFunction, ICreateReplayLastSourceInitialValue } from '@lirx/core';
import { input } from './input';

export type IAsymmetricInput<GObserverValue, GValue extends GObserverValue> = Omit<IMulticastReplayLastSource<GValue>, 'emit'> & {
  emit: IObserver<GObserverValue>;
};

export type IGenericAsymmetricInput = IAsymmetricInput<any, any>;

export function asymmetricInput<GObserverValue, GValue extends GObserverValue>(
  map: IMapFunction<any, any>,
  ...initialValue: ICreateReplayLastSourceInitialValue<GValue>
): IAsymmetricInput<GObserverValue, GValue> {
  const {
    emit: _emit,
    ...properties
  } = input<GValue>(...initialValue);

  const emit = (
    value: GObserverValue,
  ): void => {
    _emit(map(value));
  };

  return {
    ...properties,
    emit,
  };
}

// export function asymmetricInput<GObserverValue, GValue extends GObserverValue>(
//   map: IMapFunction<any, any>,
//   ...initialValue: ICreateReplayLastSourceInitialValue<GObserverValue>
// ): IAsymmetricInput<GObserverValue, GValue> {
//   const {
//     emit: _emit,
//     ...properties
//   } = (initialValue.length === 0)
//     ? input<GValue>()
//     : input<GValue>(map(initialValue[0]));
//
//   const emit = (
//     value: GObserverValue,
//   ): void => {
//     _emit(map(value));
//   };
//
//   return {
//     ...properties,
//     emit,
//   };
// }
