import { createMulticastReplayLastSource, IMulticastReplayLastSource } from '@lirx/core';

export type IInput<GValue> = IMulticastReplayLastSource<GValue>;

export type IGenericInput = IInput<any>;

export const input = createMulticastReplayLastSource;


