import { createMulticastSource, IMulticastSource } from '@lirx/core';

export type IOutput<GValue> = IMulticastSource<GValue>;

export type IGenericOutput = IOutput<any>;

export const output = createMulticastSource;
