import { IUnsubscribe } from '@lirx/utils';
import { VirtualComponentNode } from '../../virtual-component-node.class';
import {
  InferCaseInsensitiveDataKeyOfVirtualComponentNode,
  getCaseInsensitiveDataKeyOfVirtualComponentNode,
} from '../get-case-insensitive-data-key-of-virtual-component-node';
import { InferObserverForDataObservable } from '../../types/data/infer-observer-for-data-observable.type';

export function bindCaseInsensitiveDataObservableWithObserver<GData extends object, GCaseInsensitiveKey extends string>(
  node: VirtualComponentNode<any, GData>,
  key: GCaseInsensitiveKey,
  $value: InferObserverForDataObservable<GData, InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>>,
): IUnsubscribe {
  type GKey = InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>;
  return node.bindDataObservableWithObserver<GKey>(
    getCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>(node, key),
    $value,
  );
}
