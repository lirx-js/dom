import { IUnsubscribe } from '@lirx/utils';
import { VirtualComponentNode } from '../../virtual-component-node.class';
import {
  InferCaseInsensitiveDataKeyOfVirtualComponentNode,
  getCaseInsensitiveDataKeyOfVirtualComponentNode,
} from '../get-case-insensitive-data-key-of-virtual-component-node';
import { InferObservableForDataObserver } from '../../types/data/infer-observable-for-data-observer.type';

export function bindCaseInsensitiveDataObserverWithObservable<GData extends object, GCaseInsensitiveKey extends string>(
  node: VirtualComponentNode<any, GData>,
  key: GCaseInsensitiveKey,
  $value: InferObservableForDataObserver<GData, InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>>,
): IUnsubscribe {
  type GKey = InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>;
  return node.bindDataObserverWithObservable<GKey>(
    getCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>(node, key),
    $value,
  );
}
