import {
  IMulticastReplayLastSource,
  IMapFunction,
  ICreateReplayLastSourceInitialValue,
  createMulticastReplayLastSource,
  IObserver,
  IObservable,
} from '@lirx/core';

export class AsymmetricInput<GObserverValue, GValue extends GObserverValue> {
  readonly #source: IMulticastReplayLastSource<GValue>;

  constructor(
    map: IMapFunction<any, any>,
    ...initialValue: ICreateReplayLastSourceInitialValue<GValue>
  ) {
    this.#source = createMulticastReplayLastSource<GValue>(...initialValue);
  }

  get emit(): IObserver<GValue> {
    return this.#source.emit;
  }

  get subscribe(): IObservable<GValue> {
    return this.#source.subscribe;
  }

  get value(): GValue {
    return this.#source.getValue();
  }
}
