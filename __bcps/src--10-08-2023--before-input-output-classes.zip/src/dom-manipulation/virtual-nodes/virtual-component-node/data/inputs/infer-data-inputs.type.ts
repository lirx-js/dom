import { IInput, IGenericInput } from '../../../../../component/classes/types/init-component-data/helpers/input';
import { IAsymmetricInput, IGenericAsymmetricInput } from '../../../../../component/classes/types/init-component-data/helpers/asymmetric-input';

export type InferDataInputs<GData extends object> = {
  [GKey in keyof GData as (GData[GKey] extends (IGenericInput | IGenericAsymmetricInput)
    ? GKey
    : never)]: GData[GKey] extends (IGenericInput | IGenericAsymmetricInput)
    ? GData[GKey]
    : never;
};

export type InferDataInputKeys<GData extends object> = keyof InferDataInputs<GData>;

export type InferDataInputValue<GInput> =
  GInput extends IInput<infer GValue>
    ? GValue
    : (
      GInput extends IAsymmetricInput<any, infer GValue>
        ? GValue
        : never
      )
  ;
