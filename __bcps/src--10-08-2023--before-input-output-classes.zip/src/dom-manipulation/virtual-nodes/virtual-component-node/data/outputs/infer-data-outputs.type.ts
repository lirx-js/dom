import { IOutput, IGenericOutput } from '../../../../../component/classes/types/init-component-data/helpers/output';

export type InferDataOutputs<GData extends object> = {
  [GKey in keyof GData as (GData[GKey] extends IGenericOutput
    ? GKey
    : never)]: GData[GKey] extends IGenericOutput
    ? GData[GKey]
    : never;
};

export type InferDataOutputKeys<GData extends object> = keyof InferDataOutputs<GData>;

export type InferDataOutputValue<GInput> =
  GInput extends IOutput<infer GValue>
    ? GValue
    : never
  ;
