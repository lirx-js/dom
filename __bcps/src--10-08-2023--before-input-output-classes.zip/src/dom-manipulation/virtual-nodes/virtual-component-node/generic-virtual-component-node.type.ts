import { VirtualComponentNode } from './virtual-component-node.class';

export type IGenericVirtualComponentNode = VirtualComponentNode<any, any>;
