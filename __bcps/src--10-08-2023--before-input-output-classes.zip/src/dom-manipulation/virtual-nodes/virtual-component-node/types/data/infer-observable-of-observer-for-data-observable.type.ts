import { IUnknownToObservableStrict, IObservable, IObserver, IInferObservableGValue } from '@lirx/core';

export type InferObservableOfObserverForDataObservable<GData extends object, GKey extends keyof GData> =
  IUnknownToObservableStrict<GData[GKey]> extends never
    ? never
    : IObservable<IObserver<IInferObservableGValue<IUnknownToObservableStrict<GData[GKey]>>>>
  ;
