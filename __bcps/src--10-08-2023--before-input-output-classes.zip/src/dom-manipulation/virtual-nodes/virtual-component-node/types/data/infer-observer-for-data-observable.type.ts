import { IUnknownToObservableStrict, IObserver, IInferObservableGValue } from '@lirx/core';

export type InferObserverForDataObservable<GData extends object, GKey extends keyof GData> =
  IUnknownToObservableStrict<GData[GKey]> extends never
    ? never
    : IObserver<IInferObservableGValue<IUnknownToObservableStrict<GData[GKey]>>>
  ;
