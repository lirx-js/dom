import { HTML_NAMESPACE_URI_CONSTANT } from '../../misc/namespace-uri/html-namespace-uri.constant';
import { VirtualReactiveElementNode } from '../virtual-reactive-element-node/virtual-reactive-element-node.class';
import { IVirtualComponentNodeSlotsMap } from './types/slots/virtual-component-node-slots-map.type';
import { IVirtualComponentNodeOptions } from './types/options/virtual-component-node-options.type';
import { IUnsubscribe } from '@lirx/utils';
import {
  subscribeToObservableUsingAnObservableOfObserver,
  unknownToObserver,
  unknownToObservableStrict,
  IUnknownToObservableStrict,
  IUnknownToObserver,
  IObservable,
  IObserver, signal,
} from '@lirx/core';
import { InferObservableOfObserverForDataObservable } from './types/data/infer-observable-of-observer-for-data-observable.type';
import { InferObserverForDataObservable } from './types/data/infer-observer-for-data-observable.type';
import { InferObservableForDataObserver } from './types/data/infer-observable-for-data-observer.type';
import { InferDataOutputValue, InferDataOutputKeys, InferDataOutputs } from './data/outputs/infer-data-outputs.type';
import { InferDataInputValue, InferDataInputKeys, InferDataInputs } from './data/inputs/infer-data-inputs.type';
import { input } from '../../../component/classes/types/init-component-data/helpers/input';

/**
 * Represents an instance of a Component.
 * It has:
 * - a name
 * - some slots
 * - and some 'data'
 */
export class VirtualComponentNode<GElement extends Element, GData extends object> extends VirtualReactiveElementNode<GElement> {
  readonly #name: string;
  readonly #extends: string | undefined;
  readonly #slots: IVirtualComponentNodeSlotsMap;

  readonly #data: GData;

  constructor(
    {
      name,
      extends: _extends,
      namespaceURI = HTML_NAMESPACE_URI_CONSTANT,
      slots,
      data,
    }: IVirtualComponentNodeOptions<GData>,
  ) {
    super(
      namespaceURI,
      (_extends === void 0)
        ? name
        : _extends,
    );
    this.#name = name;
    this.#extends = _extends;
    this.#slots = slots;
    this.#data = data;

    if (_extends !== void 0) {
      this.setAttribute('is', name);
    }
  }

  get name(): string {
    return this.#name;
  }

  get extends(): string | undefined {
    return this.#extends;
  }

  get slots(): IVirtualComponentNodeSlotsMap {
    return this.#slots;
  }

  get data(): GData {
    return this.#data;
  }

  /* INPUTS */

  get inputs(): InferDataInputs<GData> {
    return this.#data;
  }

  inputValue<GKey extends InferDataInputKeys<GData>>(
    key: GKey,
  ): InferDataInputValue<GData[GKey]> {
    return this.inputs[key].getValue();
  }

  input$<GKey extends InferDataInputKeys<GData>>(
    key: GKey,
  ): IObservable<InferDataInputValue<GData[GKey]>> {
    return this.inputs[key].subscribe;
  }

  $input<GKey extends InferDataInputKeys<GData>>(
    key: GKey,
  ): IObserver<InferDataInputValue<GData[GKey]>> {
    return this.inputs[key].emit;
  }

  bindInputWithObservable<GKey extends InferDataInputKeys<GData>>(
    key: GKey,
    value$: IObservable<InferDataInputValue<GData[GKey]>>,
  ): IUnsubscribe {
    return this.onConnected((): IUnsubscribe => {
      return value$(this.$input<GKey>(key));
    });
  }

  /* OUTPUTS */

  get outputs(): InferDataOutputs<GData> {
    return this.#data;
  }

  output$<GKey extends InferDataOutputKeys<GData>>(
    key: GKey,
  ): IObservable<InferDataOutputValue<GData[GKey]>> {
    return this.outputs[key].subscribe;
  }

  $output<GKey extends InferDataOutputKeys<GData>>(
    key: GKey,
  ): IObserver<InferDataOutputValue<GData[GKey]>> {
    return this.outputs[key].emit;
  }

  bindOutputWithObserver<GKey extends InferDataOutputKeys<GData>>(
    key: GKey,
    $value: IObserver<InferDataInputValue<GData[GKey]>>,
  ): IUnsubscribe {
    return this.onConnected((): IUnsubscribe => {
      return this.output$<GKey>(key)($value);
    });
  }

  /**
   * BINDING
   *
   * **CAUTION**: use these methods only if you perfectly know what you're doing.
   */

  // dataObservable<GKey extends keyof GData>(
  //   key: GKey,
  // ): IObservable<IUnknownToObservableValue<GData[GKey], 'strict'>>;
  // dataObservable<GKey extends keyof GData, GMode extends IUnknownToObservableMode>(
  //   key: GKey,
  //   mode: GMode,
  //   options?: IUnknownToObservableOptions,
  // ): IObservable<IUnknownToObservableValue<GData[GKey], GMode>>;
  // dataObservable<GKey extends keyof GData, GMode extends IUnknownToObservableMode>(
  //   key: GKey,
  //   mode: GMode = 'strict' as GMode,
  //   options?: IUnknownToObservableOptions,
  // ): IObservable<IUnknownToObservableValue<GData[GKey], GMode>> {
  //   return unknownToObservable<GData[GKey], GMode>(this.data[key], mode, options);
  // }

  dataObservable<GKey extends keyof GData>(
    key: GKey,
  ): IUnknownToObservableStrict<GData[GKey]> {
    return unknownToObservableStrict<GData[GKey]>(this.data[key]);
  }

  dataObserver<GKey extends keyof GData>(
    key: GKey,
  ): IUnknownToObserver<GData[GKey]> {
    return unknownToObserver<GData[GKey]>(this.data[key]);
  }

  bindDataObserverWithObservable<GKey extends keyof GData>(
    key: GKey,
    value$: InferObservableForDataObserver<GData, GKey>,
  ): IUnsubscribe {
    return this.onConnected((): IUnsubscribe => {
      return value$(this.dataObserver<GKey>(key));
    });
  }

  bindDataObservableWithObserver<GKey extends keyof GData>(
    key: GKey,
    $value: InferObserverForDataObservable<GData, GKey>,
  ): IUnsubscribe {
    return this.onConnected((): IUnsubscribe => {
      return this.dataObservable<GKey>(key)($value);
    });
  }

  bindDataObservableWithObservableOfObserver<GKey extends keyof GData>(
    key: GKey,
    $value: InferObservableOfObserverForDataObservable<GData, GKey>,
  ): IUnsubscribe {
    return this.onConnected((): IUnsubscribe => {
      return subscribeToObservableUsingAnObservableOfObserver<any>(
        this.dataObservable<GKey>(key),
        $value,
      );
    });
  }
}

/*-------------------*/

/*-------------------*/

// interface TestConfig {
//   element: HTMLButtonElement;
//   inputs:
//     | ['i-a', boolean]
//     | ['o-a', number]
//     | ['o-b', string]
//   ,
// }
//
// const a = new VirtualComponentNode({
//   name: 'test',
//   slots: new Map(),
//   data: [
//     ['i-a', true],
//     'o-b',
//     ['o-a'],
//   ],
// });

const a = new VirtualComponentNode({
  name: 'test',
  slots: new Map(),
  data: {
    a: signal(6),
    b: input(6),
    c: '',
  },
});

const h = a.inputs.b;
const g = a.input$('b');

// //
// // a.properties.get('i-a');
// // a.properties.set('o-a', 4);
// //
// a.bindDataObserverWithObservable('a', single(8));
// // a.bindOutputWithObserver('a', (_: string) => {});
// // a.setReactiveOutput('i-a', (value: boolean) => {})
// // a.setReactiveOutput('o-a', (value: number) => {})
