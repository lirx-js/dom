import { IUnsubscribe } from '@lirx/utils';
import {
  VirtualComponentNode,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/virtual-component-node.class';
import { inlineLastLines } from '../../../../../misc/lines/functions/after-last-line';
import { ILines } from '../../../../../misc/lines/lines.type';
import {
  ITranspileSetReactiveOutputToJSLinesFunction,
  ITranspileSetReactiveOutputToJSLinesOptions,
} from '../../transpilers/transpile-set-reactive-output-to-js-lines.type';
import {
  InferObserverForDataObservable,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/types/data/infer-observer-for-data-observable.type';
import {
  InferCaseInsensitiveDataKeyOfVirtualComponentNode,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/case-insensitive/get-case-insensitive-data-key-of-virtual-component-node';
import {
  bindCaseInsensitiveDataObservableWithObservableOfObserver,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/case-insensitive/bind/bind-case-insensitive-data-observable-with-observable-of-observer';
import {
  InferObservableOfObserverForDataObservable,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/types/data/infer-observable-of-observer-for-data-observable.type';
import {
  bindCaseInsensitiveDataObservableWithObserverLike,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/case-insensitive/bind/bind-case-insensitive-data-observable-with-observer-like';

export const transpileAOTSetReactiveOutputToJSLines: ITranspileSetReactiveOutputToJSLinesFunction = (
  {
    node,
    name,
    value,
    observableMode,
  }: ITranspileSetReactiveOutputToJSLinesOptions,
): ILines => {
  return inlineLastLines(
    [
      observableMode
        ? `aot_17(`
        : `aot_18(`,
    ],
    [],
    node,
    [', '],
    name,
    [', '],
    value,
    [');'],
  );
};

export function aot_17<GData extends object, GCaseInsensitiveKey extends string>(
  node: VirtualComponentNode<any, GData>,
  key: GCaseInsensitiveKey,
  $value: InferObservableOfObserverForDataObservable<GData, InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>>,
): IUnsubscribe {
  return bindCaseInsensitiveDataObservableWithObservableOfObserver<GData, GCaseInsensitiveKey>(
    node,
    key,
    $value,
  );
}

export function aot_18<GData extends object, GCaseInsensitiveKey extends string>(
  node: VirtualComponentNode<any, GData>,
  key: GCaseInsensitiveKey,
  $value: InferObserverForDataObservable<GData, InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>> | undefined,
): IUnsubscribe {
  return bindCaseInsensitiveDataObservableWithObserverLike<GData, GCaseInsensitiveKey>(
    node,
    key,
    $value,
  );
}






