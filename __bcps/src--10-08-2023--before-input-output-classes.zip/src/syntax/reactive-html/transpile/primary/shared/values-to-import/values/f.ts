import { computed } from '@lirx/core';

/**
 * @deprecated
 * @internal
 */
export const f = computed;
