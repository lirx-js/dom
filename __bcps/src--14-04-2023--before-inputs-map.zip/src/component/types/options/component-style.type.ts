import { IGenericVirtualElementNode } from '../../../virtual-node/dom/nodes/static/element/virtual-element-node.class';

export interface IComponentStyle {
  (
    node: IGenericVirtualElementNode,
  ): void;
}
