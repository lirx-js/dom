import { ITypedSourcesMapEntriesTuple } from '../../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  ICaseInsensitiveTypedSourcesMap$SetCaseInsensitiveFunction,
} from './case-insensitive-typed-sources-map.$set-case-insensitive.function';

export interface ICaseInsensitiveTypedSourcesMap$SetCaseInsensitiveTrait<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> {
  $setCaseInsensitive: ICaseInsensitiveTypedSourcesMap$SetCaseInsensitiveFunction<GTypedSourcesTuple>;
}
