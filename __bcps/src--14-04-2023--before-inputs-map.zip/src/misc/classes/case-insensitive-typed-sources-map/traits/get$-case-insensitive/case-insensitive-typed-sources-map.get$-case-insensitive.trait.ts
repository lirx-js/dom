import { ITypedSourcesMapEntriesTuple } from '../../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  ICaseInsensitiveTypedSourcesMapGet$CaseInsensitiveFunction,
} from './case-insensitive-typed-sources-map.get$-case-insensitive.function';

export interface ICaseInsensitiveTypedSourcesMapGet$CaseInsensitiveTrait<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> {
  get$CaseInsensitive: ICaseInsensitiveTypedSourcesMapGet$CaseInsensitiveFunction<GTypedSourcesTuple>;
}
