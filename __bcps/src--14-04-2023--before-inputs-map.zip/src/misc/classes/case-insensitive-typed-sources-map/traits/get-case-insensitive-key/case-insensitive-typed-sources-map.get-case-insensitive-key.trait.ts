import { ITypedSourcesMapEntriesTuple } from '../../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import { ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveKeyFunction } from './case-insensitive-typed-sources-map.get-case-insensitive-key.function';

export interface ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveKeyTrait<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> {
  getCaseInsensitiveKey: ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveKeyFunction<GTypedSourcesTuple>;
}
