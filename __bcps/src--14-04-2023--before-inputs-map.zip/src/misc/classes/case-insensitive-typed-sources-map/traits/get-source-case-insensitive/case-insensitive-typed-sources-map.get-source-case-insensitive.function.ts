import { IMulticastReplayLastSource } from '@lirx/core';
import {
  InferTypedSourcesMapEntriesTupleValueFromKey
} from '../../../typed-sources-map/types/infer-typed-sources-map-entries-tuple-value-from-key.infer';
import { ITypedSourcesMapEntriesTuple } from '../../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey
} from '../../types/infer-typed-map-entries-tuple-key-from-case-insensitive-key.infer';

export interface ICaseInsensitiveTypedSourcesMapGetSourceCaseInsensitiveFunction<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> {
  <GKey extends string>(
    key: GKey,
  ): IMulticastReplayLastSource<InferTypedSourcesMapEntriesTupleValueFromKey<GTypedSourcesTuple, InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey<GTypedSourcesTuple, GKey>>>;
}
