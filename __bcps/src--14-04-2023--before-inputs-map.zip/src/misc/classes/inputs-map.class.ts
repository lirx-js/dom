import { IObservable, readObservableValue } from '@lirx/core';

export type IInputsMapEntry<GKey extends string, GValue> = [
  key: GKey,
  value: GValue,
];

export type IGenericInputsMapEntry = IInputsMapEntry<any, any>;

export type IGenericInputsMapEntries = readonly IGenericInputsMapEntry[];

export type InferInputsMapKeys<GEntries extends IGenericInputsMapEntries> = {
  [Key in keyof GEntries]: GEntries[Key][0];
}[number];

export type InferInputsMapValueFromKey<GEntries extends IGenericInputsMapEntries, GKey extends string> = {
  [Key in keyof GEntries]: GEntries[Key][0] extends GKey
    ? GEntries[Key][1]
    : never;
}[number];

export type InferInputsMapInputEntries<GEntries extends IGenericInputsMapEntries> = {
  readonly [Key in keyof GEntries]: [GEntries[Key][0], IObservable<GEntries[Key][1]>];
};

export class InputsMap<GEntries extends IGenericInputsMapEntries> {

  protected _map: Map<string, IObservable<unknown>>;

  constructor(
    entries: InferInputsMapInputEntries<GEntries>,
  ) {
    this._map = new Map<string, IObservable<unknown>>(entries);
  }

  get$<GKey extends InferInputsMapKeys<GEntries>>(
    key: GKey,
  ): IObservable<InferInputsMapValueFromKey<GEntries, GKey>> {
    const value: IObservable<unknown> | undefined = this._map.get(key);
    if (value === void 0) {
      throw new Error(`Input '${key}' does not exist`);
    } else {
      return value as IObservable<InferInputsMapValueFromKey<GEntries, GKey>>;
    }
  }

  get<GKey extends InferInputsMapKeys<GEntries>>(
    key: GKey,
  ): InferInputsMapValueFromKey<GEntries, GKey> {
    return readObservableValue(this.get$(key), (): never => {
      throw new Error(`Unable to read input: ${key}`);
    });
  }
}

/*---------------------*/

// type A = [
//   ['A', string],
//   ['b', boolean],
// ];
//
// const a = new InputsMap<A>([
//   ['A', single('0')],
//   ['b', single(false)],
// ]);
//
// const b = a.get$('A');
