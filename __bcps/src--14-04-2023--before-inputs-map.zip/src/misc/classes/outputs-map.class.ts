import { IObservable, IObserver, single } from '@lirx/core';

export type IOutputsMapEntry<GKey extends string, GValue> = [
  key: GKey,
  value: GValue,
];

export type IGenericOutputsMapEntry = IOutputsMapEntry<any, any>;

export type IGenericOutputsMapEntries = readonly IGenericOutputsMapEntry[];

export type InferOutputsMapKeys<GEntries extends IGenericOutputsMapEntries> = {
  [Key in keyof GEntries]: GEntries[Key][0];
}[number];

export type InferOutputsMapValueFromKey<GEntries extends IGenericOutputsMapEntries, GKey extends string> = {
  [Key in keyof GEntries]: GEntries[Key][0] extends GKey
    ? GEntries[Key][1]
    : never;
}[number];

export type InferOutputsMapInputEntries<GEntries extends IGenericOutputsMapEntries> = {
  readonly [Key in keyof GEntries]: [GEntries[Key][0], IObserver<GEntries[Key][1]>];
};

export class OutputsMap<GEntries extends IGenericOutputsMapEntries> {

  protected _map: Map<string, IObserver<unknown>>;

  constructor(
    entries: InferOutputsMapInputEntries<GEntries>,
  ) {
    this._map = new Map<string, IObserver<unknown>>(entries);
  }

  $set<GKey extends InferOutputsMapKeys<GEntries>>(
    key: GKey,
  ): IObserver<InferOutputsMapValueFromKey<GEntries, GKey>> {
    const value: IObserver<unknown> | undefined = this._map.get(key);
    if (value === void 0) {
      throw new Error(`Output '${key}' does not exist`);
    } else {
      return value as IObservable<InferOutputsMapValueFromKey<GEntries, GKey>>;
    }
  }

  set<GKey extends InferOutputsMapKeys<GEntries>>(
    key: GKey,
    value: InferOutputsMapValueFromKey<GEntries, GKey>,
  ): void {
    this.$set(key)(value);
  }
}

/*---------------------*/


// type A = [
//   ['A', string],
//   ['b', boolean],
// ];
//
// const a = new OutputsMap<A>([
//   ['A', () => {}],
//   ['b', () => {}],
// ]);
//
// const b = a.$set('A');
