export type ILines = string[];
