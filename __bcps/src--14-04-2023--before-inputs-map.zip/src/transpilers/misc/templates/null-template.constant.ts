export const NULL_TEMPLATE: string = 'null';
