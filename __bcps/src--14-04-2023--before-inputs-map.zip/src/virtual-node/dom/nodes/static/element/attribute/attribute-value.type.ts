export type IAttributeValue =
  | string
  | null
  ;
