import {
  IVirtualCustomElementNodeOptions,
} from '../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/members/options/virtual-custom-element-node-options.type';
import { IComponentConfig } from '../config/component-config.type';
import { InferComponentConfigData } from '../config/infer-component-config-data.type';
import { IComponentStyle } from './component-style.type';
import { IComponentTemplate } from './component-template.type';
import { InferComponentInitInterface } from './infer-component-init-interface.type';

export type ICreateComponentOptions<GConfig extends IComponentConfig> = {
    template?: IComponentTemplate<InferComponentConfigData<GConfig>> | undefined;
    styles?: (readonly IComponentStyle[]) | undefined;
  }
  & Omit<IVirtualCustomElementNodeOptions<GConfig>, 'slots'>
  & InferComponentInitInterface<GConfig>
  ;
