import { getHTMLElementTabIndex } from '../../../focus/get-html-element-tab-index';

/**
 * Returns true if a focusable element is tabbable.
 * It must have a non negative tabindex
 */
export function isFocusableHTMLElementTabbable(
  element: HTMLElement,
): boolean {
  return getHTMLElementTabIndex(element) >= 0;
}
