export function getElementTagName(
  node: Element,
): string {
  return node.tagName.toLowerCase();
}

