import { IGenericObservablesMapEntries } from '../../../../../../misc/classes/observables-map.class';

export type IVirtualCustomElementNodeConfigInputs = IGenericObservablesMapEntries;

