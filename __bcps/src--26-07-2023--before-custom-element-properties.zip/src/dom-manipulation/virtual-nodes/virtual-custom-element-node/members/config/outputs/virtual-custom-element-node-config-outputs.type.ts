import { IGenericObserversMapEntries } from '../../../../../../misc/classes/observers-map.class';

export type IVirtualCustomElementNodeConfigOutputs = IGenericObserversMapEntries;

