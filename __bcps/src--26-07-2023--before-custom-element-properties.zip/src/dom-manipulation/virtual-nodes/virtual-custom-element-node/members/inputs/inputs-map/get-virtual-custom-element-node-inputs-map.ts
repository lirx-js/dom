import { IGenericVirtualCustomElementNode } from '../../../generic-virtual-custom-element-node.type';
import { IVirtualCustomElementNodeInputsMap } from './create-virtual-custom-element-node-inputs-map';

const VIRTUAL_CUSTOM_ELEMENT_NODE_TO_INPUTS_MAP = new WeakMap<IGenericVirtualCustomElementNode, IVirtualCustomElementNodeInputsMap>();

export function getVirtualCustomElementNodeInputsMap(
  node: IGenericVirtualCustomElementNode,
): IVirtualCustomElementNodeInputsMap {
  return VIRTUAL_CUSTOM_ELEMENT_NODE_TO_INPUTS_MAP.get(node)!;
}


export function registerVirtualCustomElementNodeInputsMap(
  node: IGenericVirtualCustomElementNode,
  inputsMap: IVirtualCustomElementNodeInputsMap,
): void {
  VIRTUAL_CUSTOM_ELEMENT_NODE_TO_INPUTS_MAP.set(node, inputsMap);
}
