import { IGenericVirtualCustomElementNode } from '../../../generic-virtual-custom-element-node.type';
import { IVirtualCustomElementNodeOutputsMap } from './create-virtual-custom-element-node-outputs-map';

const VIRTUAL_CUSTOM_ELEMENT_NODE_TO_OUTPUTS_MAP = new WeakMap<IGenericVirtualCustomElementNode, IVirtualCustomElementNodeOutputsMap>();

export function getVirtualCustomElementNodeOutputsMap(
  node: IGenericVirtualCustomElementNode,
): IVirtualCustomElementNodeOutputsMap {
  return VIRTUAL_CUSTOM_ELEMENT_NODE_TO_OUTPUTS_MAP.get(node)!;
}


export function registerVirtualCustomElementNodeOutputsMap(
  node: IGenericVirtualCustomElementNode,
  outputsMap: IVirtualCustomElementNodeOutputsMap,
): void {
  VIRTUAL_CUSTOM_ELEMENT_NODE_TO_OUTPUTS_MAP.set(node, outputsMap);
}
