import { ISetStyleProperty } from '../../../virtual-element-node/members/style/style-property.type';

export type IStylePropertiesMap = Map<string, ISetStyleProperty>;
