import { f } from './values/f';
import { f$ } from './values/f$';

export const SHARED_VALUES_TO_IMPORT = {
  f,
  f$,
};
