import {
  IVirtualComponentNodeSlotsMap,
} from '../../../../dom-manipulation/virtual-nodes/virtual-component-node/types/slots/virtual-component-node-slots-map.type';

export const DEFAULT_SLOTS: IVirtualComponentNodeSlotsMap = new Map();
