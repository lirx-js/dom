import { IUnsubscribe } from '@lirx/utils';
import { VirtualComponentNode } from '../../virtual-component-node.class';
import {
  InferCaseInsensitiveDataKeyOfVirtualComponentNode,
  getCaseInsensitiveDataKeyOfVirtualComponentNode,
} from '../get-case-insensitive-data-key-of-virtual-component-node';
import { InferObservableOfObserverForDataObservable } from '../../types/data/infer-observable-of-observer-for-data-observable.type';

export function bindCaseInsensitiveDataObservableWithObservableOfObserver<GData extends object, GCaseInsensitiveKey extends string>(
  node: VirtualComponentNode<any, GData>,
  key: GCaseInsensitiveKey,
  $value: InferObservableOfObserverForDataObservable<GData, InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>>,
): IUnsubscribe {
  type GKey = InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>;
  return node.bindDataObservableWithObservableOfObserver<GKey>(
    getCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>(node, key),
    $value,
  );
}
