import { IUnsubscribe } from '@lirx/utils';
import { VirtualComponentNode } from '../../virtual-component-node.class';
import { InferCaseInsensitiveDataKeyOfVirtualComponentNode } from '../get-case-insensitive-data-key-of-virtual-component-node';
import { InferObservableForDataObserver } from '../../types/data/infer-observable-for-data-observer.type';
import { unknownToObservableNotUndefined } from '@lirx/core';
import { bindCaseInsensitiveDataObserverWithObservable } from './bind-case-insensitive-data-observer-with-observable';

export function bindCaseInsensitiveDataObserverWithObservableLike<GData extends object, GCaseInsensitiveKey extends string>(
  node: VirtualComponentNode<any, GData>,
  key: GCaseInsensitiveKey,
  value$: InferObservableForDataObserver<GData, InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>> | unknown,
): IUnsubscribe {
  return bindCaseInsensitiveDataObserverWithObservable<GData, GCaseInsensitiveKey>(
    node,
    key,
    unknownToObservableNotUndefined(value$) as any,
  );
}
