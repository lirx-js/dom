import { IUnsubscribe } from '@lirx/utils';
import { VirtualComponentNode } from '../../virtual-component-node.class';
import {
  InferCaseInsensitiveDataKeyOfVirtualComponentNode,
  getCaseInsensitiveDataKeyOfVirtualComponentNode,
} from '../get-case-insensitive-data-key-of-virtual-component-node';
import { InferObservableForDataObserver } from '../../types/data/infer-observable-for-data-observer.type';
import { unknownToObserver } from '@lirx/core';

export function bindCaseInsensitiveDataObserverWithObservable<GData extends object, GCaseInsensitiveKey extends string>(
  node: VirtualComponentNode<any, GData>,
  key: GCaseInsensitiveKey,
  value$: InferObservableForDataObserver<GData, InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>>,
): IUnsubscribe {
  type GKey = InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>;

  const _key: GKey = getCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>(node, key);
  return node.onConnected((): IUnsubscribe => {
    return value$(
      unknownToObserver<GData[GKey]>(node.data[_key])
    );
  });

  // return node.bindOutputWithObserver<GKey>(
  //   getCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>(node, key),
  //   value$,
  // );
  //
  // return node.bindDataObserverWithObservable<GKey>(
  //   getCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>(node, key),
  //   value$,
  // );
}
