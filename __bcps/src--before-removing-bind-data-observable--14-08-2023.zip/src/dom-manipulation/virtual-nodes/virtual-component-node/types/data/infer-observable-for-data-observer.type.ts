import { IUnknownToObserver, IObservable, IInferObserverGValue } from '@lirx/core';

export type InferObservableForDataObserver<GData extends object, GKey extends keyof GData> =
  IUnknownToObserver<GData[GKey]> extends never
    ? never
    : IObservable<IInferObserverGValue<IUnknownToObserver<GData[GKey]>>>
  ;
