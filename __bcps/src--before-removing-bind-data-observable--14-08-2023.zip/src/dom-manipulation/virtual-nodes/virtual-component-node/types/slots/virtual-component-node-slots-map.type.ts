import { IVirtualComponentNodeSlotTemplate } from './virtual-component-node-slot-template.type';

export type IVirtualComponentNodeSlotsMap = ReadonlyMap<string | '*', IVirtualComponentNodeSlotTemplate<object>>;
