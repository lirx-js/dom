import { IUnsubscribe } from '@lirx/utils';
import {
  VirtualComponentNode,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/virtual-component-node.class';
import { inlineLastLines } from '../../../../../misc/lines/functions/after-last-line';
import { ILines } from '../../../../../misc/lines/lines.type';
import {
  ITranspileSetReactiveInputToJSLinesFunction,
  ITranspileSetReactiveInputToJSLinesOptions,
} from '../../transpilers/transpile-set-reactive-input-to-js-lines.type';
import {
  InferObservableForDataObserver,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/types/data/infer-observable-for-data-observer.type';
import {
  InferCaseInsensitiveDataKeyOfVirtualComponentNode,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/case-insensitive/get-case-insensitive-data-key-of-virtual-component-node';
import {
  bindCaseInsensitiveDataObserverWithObservableLike,
} from '../../../../../../dom-manipulation/virtual-nodes/virtual-component-node/case-insensitive/bind/bind-case-insensitive-data-observer-with-observable-like';

export const transpileAOTSetReactiveInputToJSLines: ITranspileSetReactiveInputToJSLinesFunction = (
  {
    node,
    name,
    value,
  }: ITranspileSetReactiveInputToJSLinesOptions,
): ILines => {
  return inlineLastLines(
    [`aot_16(`],
    node,
    [', '],
    name,
    [', '],
    value,
    [');'],
  );
};

export function aot_16<GData extends object, GCaseInsensitiveKey extends string>(
  node: VirtualComponentNode<any, GData>,
  key: GCaseInsensitiveKey,
  value$: InferObservableForDataObserver<GData, InferCaseInsensitiveDataKeyOfVirtualComponentNode<GData, GCaseInsensitiveKey>> | unknown,
): IUnsubscribe {
  return bindCaseInsensitiveDataObserverWithObservableLike<GData, GCaseInsensitiveKey>(
    node,
    key,
    value$,
  );
}

