export * from './typed-sources-map.has.function';
export * from './typed-sources-map.has.trait';
