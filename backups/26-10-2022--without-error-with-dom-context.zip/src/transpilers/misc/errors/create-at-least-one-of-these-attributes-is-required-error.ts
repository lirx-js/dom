export function createAtLeastOneOfTheseAttributesIsRequiredError(
  attributNames: readonly string[],
): Error {
  return new Error(`At least one of these attributes is required: ${attributNames.map(_ => `'${_}'`).join(', ')}`);
}
