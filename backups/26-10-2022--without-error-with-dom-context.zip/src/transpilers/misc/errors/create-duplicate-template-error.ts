export function createDuplicateTemplateError(
  templateName: string,
): Error {
  return new Error(`The template '${templateName}' is already defined`);
}
