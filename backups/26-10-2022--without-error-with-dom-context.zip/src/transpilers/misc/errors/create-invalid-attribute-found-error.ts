
export function createInvalidAttributeFoundError(
  name: string,
): Error {
  return new Error(`Found invalid attribute '${name}'`);
}

export function createInvalidAttributeFoundErrorFromAttribute(
  attribute: Attr,
): Error {
  return createInvalidAttributeFoundError(attribute.name);
}
