import { getElementTagName } from '../../../misc/dom/get-element-tag-name';

export function createInvalidElementFoundError(
  tagName: string,
): Error {
  return new Error(`Found invalid element '${tagName}'`);
}

export function createInvalidElementFoundErrorFromElement(
  node: Element,
): Error {
  return createInvalidElementFoundError(getElementTagName(node));
}
