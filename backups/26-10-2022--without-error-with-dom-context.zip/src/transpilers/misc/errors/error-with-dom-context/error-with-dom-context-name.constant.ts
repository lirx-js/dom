export const ERROR_WITH_DOM_CONTEXT_NAME = 'ErrorWithDOMContext';

export type IErrorWithDOMContextName = typeof ERROR_WITH_DOM_CONTEXT_NAME;
