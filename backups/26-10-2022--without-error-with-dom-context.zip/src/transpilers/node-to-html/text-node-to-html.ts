import { ILines } from '../misc/lines/lines.type';

export function textNodeToHTML(
  node: Text,
): ILines {
  return [
    node.data,
  ];
}
