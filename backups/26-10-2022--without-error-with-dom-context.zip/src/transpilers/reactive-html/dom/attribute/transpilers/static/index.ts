export * from './transpile-reactive-html-static-attribute-to-js-lines';
