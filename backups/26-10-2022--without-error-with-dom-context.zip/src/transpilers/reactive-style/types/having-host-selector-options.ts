export interface IHavingHostSelectorOptions {
  hostSelector: string;
}
