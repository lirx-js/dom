import { IVirtualCustomElementNodeSlotsMap } from './virtual-custom-element-node-slots-map.type';

// export const DEFAULT_VIRTUAL_CUSTOM_ELEMENT_NODE_SLOTS_MAP_CONSTANT: IVirtualCustomElementNodeSlotsMap = new Map([['*', noop]]);
export const DEFAULT_VIRTUAL_CUSTOM_ELEMENT_NODE_SLOTS_MAP_CONSTANT: IVirtualCustomElementNodeSlotsMap = new Map();
