import { IVirtualDOMNodeTemplate } from '../../../../types/virtual-dom-node-template.type';

export type IVirtualCustomElementNodeSlotTemplate = IVirtualDOMNodeTemplate<[]>; // IGenericVirtualReactiveDOMNodeTemplate
