export * from './partial-interface-if-typed-sources-tuple-is-empty.type';
