import { VirtualReactiveElementNode } from './virtual-reactive-element-node.class';

export type IGenericVirtualReactiveElementNode = VirtualReactiveElementNode<Element>;
