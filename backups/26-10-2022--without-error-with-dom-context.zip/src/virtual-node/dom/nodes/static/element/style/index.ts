export * from './style-property.type';
