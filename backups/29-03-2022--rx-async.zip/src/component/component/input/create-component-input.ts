import { createHigherOrderObservableView, ICreateReplayLastSourceInitialValue } from '@lifaon/rx-js-light';

import { IComponentInput } from './component-input.type';

export function createComponentInput<GValue>(
  ...initialValue: ICreateReplayLastSourceInitialValue<GValue>
): IComponentInput<GValue> {
  return createHigherOrderObservableView<'value', GValue>('value', ...initialValue);
}

