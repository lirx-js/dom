export function hasAttribute(
  element: Element,
  name: string,
): boolean {
  return element.hasAttribute(name);
}
