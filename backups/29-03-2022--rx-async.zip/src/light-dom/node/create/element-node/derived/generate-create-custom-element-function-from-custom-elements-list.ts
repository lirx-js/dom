import { TAG_NAME } from '../../../../../component/component/component-tag-name.constant';
import { createMissingComponentImportRXDOMError } from '../../../../../misc/errors/rx-dom-error-1--missing-component-import';
import { createMissingTagNameForComponentRXDOMError } from '../../../../../misc/errors/rx-dom-error-2--missing-tag-name-for-component';
import { createCustomElementNotDefinedRXDOMError } from '../../../../../misc/errors/rx-dom-error-5--custom-element-not-defined';
import { getCustomElementTagName } from '../../../../custom-element/get-custom-element-tag-name';
import { isCustomElementDefined } from '../../../../custom-element/is-custom-element-defined';
import { createElement, ICreateElementOptions } from '../create-element';
import { isCustomElementConstructorReference } from './reference/sync/is-custom-element-constructor-reference';
import { ICreateCustomElementFunction } from './types/create-custom-element-function.type';
import { ICustomElementConstructorOrReference } from './types/custom-element-constructor-or-reference.type';
import { ICustomElementConstructor } from './types/custom-element-constructor.type';

export function generateCreateCustomElementFunctionFromCustomElementsList(
  customElements: ArrayLike<ICustomElementConstructorOrReference>,
): ICreateCustomElementFunction {
  const tags: Set<string> = new Set<string>();
  let resolved: boolean = false;

  const resolveTags = (): Set<string> => {
    if (!resolved) {
      for (let i = 0, l = customElements.length; i < l; i++) {
        const customElementOrReference: ICustomElementConstructorOrReference = customElements[i];

        const customElement: ICustomElementConstructor = isCustomElementConstructorReference(customElementOrReference)
          ? customElementOrReference()
          : customElementOrReference;

        if (TAG_NAME in customElement) {
          tags.add(customElement[TAG_NAME]);
        } else {
          throw createMissingTagNameForComponentRXDOMError(customElement, i);
        }
      }
      resolved = true;
    }

    return tags;
  };

  return <GElement extends Element>(
    tagName: string,
    options?: ICreateElementOptions,
  ): GElement => {
    const customElementName: string = getCustomElementTagName(tagName, options);
    const tags: Set<string> = resolveTags();
    if (!tags.has(customElementName)) {
      throw createMissingComponentImportRXDOMError(customElementName);
    } else if (!isCustomElementDefined(customElementName)) {
      throw createCustomElementNotDefinedRXDOMError(customElementName);
    } else {
      return createElement<GElement>(tagName, options);
    }
  };
}
