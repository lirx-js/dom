import { ICustomElementConstructor } from '../../types/custom-element-constructor.type';

export interface IAsyncCustomElementConstructorReferenceGetFunction {
  (): Promise<ICustomElementConstructor>;
}


export interface IAsyncCustomElementConstructorReference {
  readonly tagName: string;
  readonly get: IAsyncCustomElementConstructorReferenceGetFunction;
}
