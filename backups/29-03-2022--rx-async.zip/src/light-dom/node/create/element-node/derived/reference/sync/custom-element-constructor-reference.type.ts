import { ICustomElementConstructor } from '../../types/custom-element-constructor.type';

export interface ICustomElementConstructorReference {
  (): ICustomElementConstructor;
}
