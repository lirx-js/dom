import { ICustomElementConstructorReference } from './custom-element-constructor-reference.type';

const FUNCTION_PROTOTYPE = Object.getPrototypeOf(() => {});

export function isCustomElementConstructorReference(
  value: unknown,
): value is ICustomElementConstructorReference {
  return (typeof value === 'function')
    && (Object.getPrototypeOf(value) === FUNCTION_PROTOTYPE);
}
