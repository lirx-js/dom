import { createElement } from '../../create-element';

export type ICreateCustomElementFunction = typeof createElement;
