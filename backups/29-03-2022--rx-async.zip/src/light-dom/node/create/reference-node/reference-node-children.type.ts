export type IReferenceNodeChildren = readonly ChildNode[];
