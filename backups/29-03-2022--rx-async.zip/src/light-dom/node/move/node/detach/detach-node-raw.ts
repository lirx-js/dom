export function detachNodeRaw(
  node: ChildNode,
): void {
  node.remove();
}
