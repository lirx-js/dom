export const MATH_MAL_NAMESPACE_URI_CONSTANT = 'http://www.w3.org/1998/Math/MathML';
