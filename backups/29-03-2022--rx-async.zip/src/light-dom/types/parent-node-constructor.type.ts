export interface ParentNodeConstructor {
  new(...args: any[]): ParentNode;
}
