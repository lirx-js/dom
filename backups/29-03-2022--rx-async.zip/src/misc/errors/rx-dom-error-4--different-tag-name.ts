import { createRXDOMError } from './create-rx-dom-error';

export function createDifferentTagNameRXDOMError(
  expected: string,
  found: string,
): Error {
  return createRXDOMError(2, `Different tag name. Expected '${expected}', found '${found}'`);
}

