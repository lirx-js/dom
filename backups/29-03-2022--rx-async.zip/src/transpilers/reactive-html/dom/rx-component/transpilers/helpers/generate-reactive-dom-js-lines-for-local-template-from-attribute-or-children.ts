import { getChildNodes } from '../../../../../../light-dom/node/properties/get-child-nodes';
import { generateTemplateVariableName } from '../../../../../helpers/generate-template-variable-name';
import { NULL_TEMPLATE } from '../../../../../helpers/null-template.constant';
import { ILines, ILinesOrNull } from '../../../../../types/lines.type';
import { IRequireExternalFunction } from '../../../../require-external/require-external-function.type';
import {
  generateReactiveDOMJSLinesForLocalTemplateFromNodes,
  IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromNodes,
} from './generate-reactive-dom-js-lines-for-local-template-from-nodes';

export type IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildren =
  IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromNodes;

export type IGenerateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildrenResult = [
  templateName: string,
  templateLines: ILines,
];

export function generateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildren(
  node: Element,
  templateAttribute: string | undefined,
  childSelector: string,
  localTemplateName: string,
  localArgumentsLines: ILinesOrNull,
  requireExternalFunction: IRequireExternalFunction<IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildren>,
): IGenerateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildrenResult {
  if (templateAttribute === void 0) {
    const templateComponent: Element | null = node.querySelector(`:scope > ${childSelector}`);
    if (templateComponent === null) {
      return [
        NULL_TEMPLATE,
        [],
      ];
    } else {
      templateComponent.remove();
      return [
        localTemplateName,
        generateReactiveDOMJSLinesForLocalTemplateFromNodes(
          getChildNodes(templateComponent),
          localTemplateName,
          localArgumentsLines,
          requireExternalFunction,
        ),
      ];
    }
  } else {
    return [
      generateTemplateVariableName(templateAttribute),
      [],
    ];
  }
}


