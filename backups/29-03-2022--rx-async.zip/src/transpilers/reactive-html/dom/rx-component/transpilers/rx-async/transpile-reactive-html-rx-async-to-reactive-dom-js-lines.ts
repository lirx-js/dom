import { getAttributeValue } from '../../../../../../light-dom/attribute/get-attribute-value';
import { hasAttribute } from '../../../../../../light-dom/attribute/has-attribute';
import { removeAttribute } from '../../../../../../light-dom/attribute/remove-attribute';
import { getTagName } from '../../../../../../light-dom/node/properties/get-tag-name';
import { hasChildElements } from '../../../../../../light-dom/node/state/has-child-elements';
import { scopeLines } from '../../../../../helpers/lines-formatting-helpers';
import { NULL_TEMPLATE } from '../../../../../helpers/null-template.constant';
import { ILines, ILinesOrNull } from '../../../../../types/lines.type';
import { IRequireExternalFunction } from '../../../../require-external/require-external-function.type';
import {
  extractRXAttributesFromReactiveHTMLAttribute,
  IMappedAttributes,
} from '../helpers/extract-rx-attributes-from-reactive-html-attribute';
import {
  generateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildren,
  IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildren,
} from '../helpers/generate-reactive-dom-js-lines-for-local-template-from-attribute-or-children';
import {
  generateReactiveDOMJSLinesForLocalTemplateFromRXContainerElement,
  IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromRXContainerElement,
} from '../helpers/generate-reactive-dom-js-lines-for-local-template-from-rx-container-element';
import {
  generateReactiveDOMJSLinesForRXAsync,
  IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForRXAsync,
} from './generate-reactive-dom-js-lines-for-rx-async';

/*
Syntax:

<rx-async
  expression="observable"
  pending="templatePending"
  fulfilled="templateFulfilled"
  rejected="rejectedRejected"
></rx-async>

 */

/*
Syntax - alternative:

<element
  *async="observable"
>
  ...content
</element>

====> equivalent

<rx-template
  name="uuid"
>
  ...content
</rx-template>
<rx-async
  observable="observable"
  fulfilled="uuid"
></rx-async>

 */

const TAG_NAME: string = 'rx-async';
const COMMAND_NAME: string = '*async';

const EXPRESSION_ATTRIBUTE_NAME: string = 'expression';
const TEMPLATE_PENDING_ATTRIBUTE_NAME: string = 'pending';
const TEMPLATE_FULFILLED_ATTRIBUTE_NAME: string = 'fulfilled';
const TEMPLATE_REJECTED_ATTRIBUTE_NAME: string = 'rejected';

const LOCAL_TEMPLATE_ARGUMENTS_LINES: ILines = [`{ value }`];

const LOCAL_TEMPLATE_NAME: string = 'template';

const LOCAL_TEMPLATE_PENDING_NAME: string = 'template_pending';
const LOCAL_TEMPLATE_FULFILLED_NAME: string = 'template_fulfilled';
const LOCAL_TEMPLATE_REJECTED_NAME: string = 'template_rejected';

const LOCAL_TEMPLATE_PENDING_CHILD_SELECTOR: string = 'rx-pending';
const LOCAL_TEMPLATE_FULFILLED_CHILD_SELECTOR: string = 'rx-fulfilled';
const LOCAL_TEMPLATE_REJECTED_CHILD_SELECTOR: string = 'rx-rejected';

const ATTRIBUTE_NAMES: Set<string> = new Set<string>([
  EXPRESSION_ATTRIBUTE_NAME,
  TEMPLATE_PENDING_ATTRIBUTE_NAME,
  TEMPLATE_FULFILLED_ATTRIBUTE_NAME,
  TEMPLATE_REJECTED_ATTRIBUTE_NAME,
]);

export type IRequireExternalFunctionKeyForTranspileReactiveHTMLRXAsyncToReactiveDOMJSLines =
  | IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForRXAsync
  | IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildren
  | IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromRXContainerElement
  ;

export function transpileReactiveHTMLRXAsyncToReactiveDOMJSLines(
  node: Element,
  requireExternalFunction: IRequireExternalFunction<IRequireExternalFunctionKeyForTranspileReactiveHTMLRXAsyncToReactiveDOMJSLines>,
): ILinesOrNull {
  const name: string = getTagName(node);
  if (name === TAG_NAME) {
    const attributes: IMappedAttributes = extractRXAttributesFromReactiveHTMLAttribute(node.attributes, ATTRIBUTE_NAMES);
    const expression: string | undefined = attributes.get(EXPRESSION_ATTRIBUTE_NAME);
    const templatePendingAttribute: string | undefined = attributes.get(TEMPLATE_PENDING_ATTRIBUTE_NAME);
    const templateFulfilledAttribute: string | undefined = attributes.get(TEMPLATE_FULFILLED_ATTRIBUTE_NAME);
    const templateRejectedAttribute: string | undefined = attributes.get(TEMPLATE_FULFILLED_ATTRIBUTE_NAME);

    if (expression === void 0) {
      throw new Error(`Missing attribute '${EXPRESSION_ATTRIBUTE_NAME}'`);
    }

    const [templatePending, templatePendingLines] = generateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildren(
      node,
      templatePendingAttribute,
      LOCAL_TEMPLATE_PENDING_CHILD_SELECTOR,
      LOCAL_TEMPLATE_PENDING_NAME,
      LOCAL_TEMPLATE_ARGUMENTS_LINES,
      requireExternalFunction,
    );

    const [templateFulfilled, templatePendingFulfilled] = generateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildren(
      node,
      templateFulfilledAttribute,
      LOCAL_TEMPLATE_FULFILLED_CHILD_SELECTOR,
      LOCAL_TEMPLATE_FULFILLED_NAME,
      LOCAL_TEMPLATE_ARGUMENTS_LINES,
      requireExternalFunction,
    );

    const [templateRejected, templateRejectedLines] = generateReactiveDOMJSLinesForLocalTemplateFromAttributeOrChildren(
      node,
      templateRejectedAttribute,
      LOCAL_TEMPLATE_REJECTED_CHILD_SELECTOR,
      LOCAL_TEMPLATE_REJECTED_NAME,
      LOCAL_TEMPLATE_ARGUMENTS_LINES,
      requireExternalFunction,
    );

    if (
      (templatePending === NULL_TEMPLATE)
      && (templateFulfilled === NULL_TEMPLATE)
      && (templateRejected === NULL_TEMPLATE)
    ) {
      throw new Error(`At least '${TEMPLATE_PENDING_ATTRIBUTE_NAME}', '${TEMPLATE_FULFILLED_ATTRIBUTE_NAME} or '${TEMPLATE_REJECTED_ATTRIBUTE_NAME}' attribute must be present`);
    }

    if (hasChildElements(node)) {
      throw new Error(`Should not have any children`);
    }

    const templateLines: ILines = [
      ...templatePendingLines,
      ...templatePendingFulfilled,
      ...templateRejectedLines,
    ];

    const lines: ILines = generateReactiveDOMJSLinesForRXAsync(
      expression,
      templatePending,
      templateFulfilled,
      templateRejected,
      requireExternalFunction,
    );

    return (
      (templateLines.length > 0)
        ? scopeLines([
          ...templateLines,
          ...lines,
        ])
        : lines
    );
  } else if (hasAttribute(node, COMMAND_NAME)) {
    const expression: string = getAttributeValue(node, COMMAND_NAME) as string;
    removeAttribute(node, COMMAND_NAME);

    return scopeLines([
      ...generateReactiveDOMJSLinesForLocalTemplateFromRXContainerElement(
        node,
        LOCAL_TEMPLATE_NAME,
        LOCAL_TEMPLATE_ARGUMENTS_LINES,
        requireExternalFunction,
      ),
      ...generateReactiveDOMJSLinesForRXAsync(
        expression,
        NULL_TEMPLATE,
        LOCAL_TEMPLATE_NAME,
        NULL_TEMPLATE,
        requireExternalFunction,
      ),
    ]);
  } else {
    return null;
  }
}

