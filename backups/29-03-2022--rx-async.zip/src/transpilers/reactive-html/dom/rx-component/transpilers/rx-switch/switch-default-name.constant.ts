export const SWITCH_DEFAULT_NAME: string = 'switchDefault';
