export const REQUIRE_CREATE_CUSTOM_ELEMENT_CONSTANT = 'createCustomElement';

export type IRequireCreateCustomElementKey = typeof REQUIRE_CREATE_CUSTOM_ELEMENT_CONSTANT;

