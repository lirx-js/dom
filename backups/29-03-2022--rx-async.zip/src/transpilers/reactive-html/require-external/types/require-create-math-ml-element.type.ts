export const REQUIRE_CREATE_MATH_ML_ELEMENT_CONSTANT = 'createMathMLElement';

export type IRequireCreateMathMLElementKey = typeof REQUIRE_CREATE_MATH_ML_ELEMENT_CONSTANT;

