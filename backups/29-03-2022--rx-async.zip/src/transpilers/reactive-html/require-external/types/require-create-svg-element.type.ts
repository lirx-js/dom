export const REQUIRE_CREATE_SVG_ELEMENT_CONSTANT = 'createSVGElement';

export type IRequireCreateSVGElementKey = typeof REQUIRE_CREATE_SVG_ELEMENT_CONSTANT;

