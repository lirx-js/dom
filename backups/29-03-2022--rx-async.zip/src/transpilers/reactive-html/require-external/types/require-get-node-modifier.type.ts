export const REQUIRE_GET_NODE_MODIFIER_CONSTANT = 'getNodeModifier';

export type IRequireGetNodeModifierKey = typeof REQUIRE_GET_NODE_MODIFIER_CONSTANT;

