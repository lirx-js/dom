export const REQUIRE_NODE_APPEND_CHILD_CONSTANT = 'nodeAppendChild';

export type IRequireNodeAppendChildKey = typeof REQUIRE_NODE_APPEND_CHILD_CONSTANT;

