export const REQUIRE_SET_REACTIVE_ATTRIBUTE_CONSTANT = 'setReactiveAttribute';

export type IRequireSetReactiveAttributeKey = typeof REQUIRE_SET_REACTIVE_ATTRIBUTE_CONSTANT;

