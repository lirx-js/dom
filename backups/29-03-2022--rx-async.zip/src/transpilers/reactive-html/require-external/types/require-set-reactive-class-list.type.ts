export const REQUIRE_SET_REACTIVE_CLASS_LIST_CONSTANT = 'setReactiveClassList';

export type IRequireSetReactiveClassListKey = typeof REQUIRE_SET_REACTIVE_CLASS_LIST_CONSTANT;

