export const REQUIRE_SET_REACTIVE_CLASS_CONSTANT = 'setReactiveClass';

export type IRequireSetReactiveClassKey = typeof REQUIRE_SET_REACTIVE_CLASS_CONSTANT;

