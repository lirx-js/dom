export const REQUIRE_SET_REACTIVE_STYLE_CONSTANT = 'setReactiveStyle';

export type IRequireSetReactiveStyleKey = typeof REQUIRE_SET_REACTIVE_STYLE_CONSTANT;

