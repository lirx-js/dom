export const REQUIRE_TO_OBSERVABLE_CONSTANT = 'toObservable';

export type IRequireToObservableKey = typeof REQUIRE_TO_OBSERVABLE_CONSTANT;
