export * from './inject-component-style';

