import { IHigherOrderObservableView } from '@lifaon/rx-js-light';

export type IComponentInput<GValue> = IHigherOrderObservableView<'value', GValue>;
