import { ICreateReplayLastSourceInitialValue } from '@lifaon/rx-js-light';
import { objectDefineProperty } from '../../../misc/object-define-property';
import { IComponentInput } from './component-input.type';
import { createComponentInput } from './create-component-input';

export function Input<GValue>(
  ...initialValue: ICreateReplayLastSourceInitialValue<GValue>
): PropertyDecorator {
  return (target: Object, propertyKey: string | symbol): void => {

    const bindInput = (
      target: any,
      input: IComponentInput<GValue>,
    ): void => {
      objectDefineProperty(target, propertyKey, {
        configurable: true,
        enumerable: true,
        get: (): IComponentInput<GValue> => {
          return input;
        },
        set: (
          value: GValue,
        ) => {
          input.value = value;
        },
      });
    };

    function get(
      this: any,
    ): IComponentInput<GValue> {
      const input: IComponentInput<GValue> = createComponentInput<GValue>(...initialValue);
      bindInput(this, input);
      return input;
    }

    function set(
      this: any,
      value: GValue,
    ): void {
      bindInput(
        this,
        createComponentInput<GValue>(value),
      );
    }

    objectDefineProperty(target, propertyKey, {
      configurable: true,
      enumerable: true,
      get,
      set,
    });
  };
}
