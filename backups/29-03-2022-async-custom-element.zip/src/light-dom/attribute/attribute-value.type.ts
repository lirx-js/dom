export type IAttributeValue = string;
export type IAttributeValueOrNull = IAttributeValue | null;
