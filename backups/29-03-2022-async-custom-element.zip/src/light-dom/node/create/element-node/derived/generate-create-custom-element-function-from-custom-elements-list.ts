import { TAG_NAME } from '../../../../../component/component/component-tag-name.constant';
import { createMissingComponentImportRXDOMError } from '../../../../../misc/errors/rx-dom-error-1--missing-component-import';
import { createMissingTagNameForComponentRXDOMError } from '../../../../../misc/errors/rx-dom-error-2--missing-tag-name-for-component';
import { createDifferentTagNameRXDOMError } from '../../../../../misc/errors/rx-dom-error-4--different-tag-name';
import { getCustomElementRegistry } from '../../../../custom-element/get-custom-element-registry';
import { getCustomElementTagName } from '../../../../custom-element/get-custom-element-tag-name';
import { isCustomElementDefined } from '../../../../custom-element/is-custom-element-defined';
import { createElement, ICreateElementOptions } from '../create-element';
import { IAsyncCustomElementConstructorReference } from './reference/async/async-custom-element-constructor-reference.type';
import { isAsyncCustomElementConstructorReference } from './reference/async/is-async-custom-element-constructor-reference';
import { ICustomElementConstructorReference } from './reference/sync/custom-element-constructor-reference.type';
import { isCustomElementConstructorReference } from './reference/sync/is-custom-element-constructor-reference';
import { ICreateCustomElementFunction } from './types/create-custom-element-function.type';
import { ICustomElementConstructorOrReference } from './types/custom-element-constructor-or-reference.type';
import { ICustomElementConstructor } from './types/custom-element-constructor.type';

export function generateCreateCustomElementFunctionFromCustomElementsList(
  customElements: ArrayLike<ICustomElementConstructorOrReference>,
): ICreateCustomElementFunction {
  const resolvedTags: Set<string> = new Set<string>();
  const customElementConstructorReferenceMap: Map<string, ICustomElementConstructorReference> = new Map<string, ICustomElementConstructorReference>();
  const asyncCustomElementConstructorReferenceMap: Map<string, IAsyncCustomElementConstructorReference> = new Map<string, IAsyncCustomElementConstructorReference>();

  const registerCustomElement = (
    customElement: ICustomElementConstructor,
    expectedTagName?: string,
  ): void => {
    if (TAG_NAME in customElement) {
      const tagName: string = customElement[TAG_NAME];
      if (
        (expectedTagName === void 0)
        || (expectedTagName === tagName)
      ) {
        resolvedTags.add(tagName);
      } else {
        createDifferentTagNameRXDOMError(expectedTagName, tagName);
      }
    } else {
      throw createMissingTagNameForComponentRXDOMError(customElement);
    }
  };

  for (let i = 0, l = customElements.length; i < l; i++) {
    const customElementOrReference: ICustomElementConstructorOrReference = customElements[i];

    if (isCustomElementConstructorReference(customElementOrReference)) {
      customElementConstructorReferenceMap.set(customElementOrReference.tagName, customElementOrReference);
    } else if (isAsyncCustomElementConstructorReference(customElementOrReference)) {
      asyncCustomElementConstructorReferenceMap.set(customElementOrReference.tagName, customElementOrReference);
    } else {
      registerCustomElement(customElementOrReference);
    }
  }

  return <GElement extends Element>(
    tagName: string,
    options?: ICreateElementOptions,
  ): GElement => {
    const customElementName: string = getCustomElementTagName(tagName, options);

    if (resolvedTags.has(customElementName)) {
      return createElement<GElement>(tagName, options);
    } else if (customElementConstructorReferenceMap.has(customElementName)) {
      registerCustomElement(customElementConstructorReferenceMap.get(customElementName)!.get(), customElementName);
      return createElement<GElement>(tagName, options);
    } else if (asyncCustomElementConstructorReferenceMap.has(customElementName)) {
      const requiresUpgrade: boolean = !isCustomElementDefined(customElementName); // not defined yet

      const element: GElement = createElement(tagName, options);

      asyncCustomElementConstructorReferenceMap.get(customElementName)!.get()
        .then((customElement: ICustomElementConstructor): void => {
          registerCustomElement(customElement, customElementName);
          if (requiresUpgrade) {
            getCustomElementRegistry().upgrade(element);
          }
        });

      return element;
    } else {
      throw createMissingComponentImportRXDOMError(tagName);
    }
  };
}

// if (resolvedTags.has(customElementName)) {
//   return createCustomElement<GElement>(tagName, options);
// } else if (resolvingTags.has(customElementName)) {
//   return createAsyncCustomElement<GElement>(
//     (): Promise<void> => {
//       return resolvingTags.get(customElementName) as Promise<void>;
//     },
//     tagName,
//     options,
//   );
// } else if (asyncCustomElementConstructorReferences.has(customElementName)) {
//   resolvingTags.add(customElementName);
//
//   // asyncCustomElementConstructorReferences.get(customElementName)!.get()
//   //   .then((customElement: ICustomElementConstructor) => {
//   //     if (getCustomElementConstructorFromTagName(customElementName) === void 0) {
//   //       throw new Error(`Missing custom element: '${customElementName}'`);
//   //     } else {
//   //       registerCustomElement(customElement);
//   //     }
//   //   });
//   return createAsyncCustomElement<GElement>(
//     (): Promise<void> => {
//       asyncCustomElementConstructorReferences.get(customElementName)!.get()
//         .then((customElement: ICustomElementConstructor) => {
//           if (getCustomElementConstructorFromTagName(customElementName) === void 0) {
//             throw new Error(`Missing custom element: '${customElementName}'`);
//           } else {
//             registerCustomElement(customElement);
//           }
//         });
//     },
//     tagName,
//     options,
//   );
// } else {
//   throw createMissingComponentImportRXDOMError(tagName);
// }

// export function generateCreateCustomElementFunctionFromCustomElementsList(
//   customElements: ArrayLike<ICustomElementConstructorOrReference>,
// ): ICreateCustomElementFunction {
//   const tags: Set<string> = new Set<string>();
//   let resolved: boolean = false;
//
//   const resolveTags = (): Set<string> => {
//     if (!resolved) {
//       for (let i = 0, l = customElements.length; i < l; i++) {
//         const customElementOrReference: ICustomElementConstructorOrReference = customElements[i];
//
//         const customElement: ICustomElementConstructor = isCustomElementConstructorReference(customElementOrReference)
//           ? customElementOrReference()
//           : customElementOrReference;
//
//         if ('TAG_NAME' in customElement) {
//           tags.add(customElement['TAG_NAME']);
//         } else {
//           throw createMissingTagNameForComponentRXDOMError(i);
//         }
//       }
//       resolved = true;
//     }
//
//     return tags;
//   };
//
//   return <GElement extends Element>(
//     tagName: string,
//   ): GElement => {
//     const tags: Set<string> = resolveTags();
//     if (!tags.has(tagName)) {
//       throw createMissingComponentImportRXDOMError(tagName);
//     } else {
//       return createCustomElement<GElement>(tagName);
//     }
//   };
// }

