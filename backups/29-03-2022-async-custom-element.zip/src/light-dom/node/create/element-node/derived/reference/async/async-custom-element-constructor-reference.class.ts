import {
  IAsyncCustomElementConstructorReference,
  IAsyncCustomElementConstructorReferenceGetFunction,
} from './async-custom-element-constructor-reference.type';

export class AsyncCustomElementConstructorReference implements IAsyncCustomElementConstructorReference {
  constructor(
    public readonly tagName: string,
    public readonly get: IAsyncCustomElementConstructorReferenceGetFunction,
  ) {
  }
}

