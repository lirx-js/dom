import { AsyncCustomElementConstructorReference } from './async-custom-element-constructor-reference.class';
import { IAsyncCustomElementConstructorReference } from './async-custom-element-constructor-reference.type';

export function isAsyncCustomElementConstructorReference(
  value: unknown,
): value is IAsyncCustomElementConstructorReference {
  return (value instanceof AsyncCustomElementConstructorReference);
}
