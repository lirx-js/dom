import {
  ICustomElementConstructorReference,
  ICustomElementConstructorReferenceGetFunction,
} from './custom-element-constructor-reference.type';

export class CustomElementConstructorReference implements ICustomElementConstructorReference {
  constructor(
    public readonly tagName: string,
    public readonly get: ICustomElementConstructorReferenceGetFunction,
  ) {
  }
}

