import { ICustomElementConstructor } from '../../types/custom-element-constructor.type';

export interface ICustomElementConstructorReferenceGetFunction {
  (): ICustomElementConstructor;
}


export interface ICustomElementConstructorReference {
  readonly tagName: string;
  readonly get: ICustomElementConstructorReferenceGetFunction;
}
