import { CustomElementConstructorReference } from './custom-element-constructor-reference.class';
import { ICustomElementConstructorReference } from './custom-element-constructor-reference.type';

export function isCustomElementConstructorReference(
  value: unknown,
): value is ICustomElementConstructorReference {
  return (value instanceof CustomElementConstructorReference);
}
