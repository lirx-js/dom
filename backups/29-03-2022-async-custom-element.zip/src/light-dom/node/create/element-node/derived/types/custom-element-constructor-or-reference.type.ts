import { IAsyncCustomElementConstructorReference } from '../reference/async/async-custom-element-constructor-reference.type';
import { ICustomElementConstructorReference } from '../reference/sync/custom-element-constructor-reference.type';
import { ICustomElementConstructor } from './custom-element-constructor.type';

export type ICustomElementConstructorOrReference =
  | ICustomElementConstructor
  | ICustomElementConstructorReference
  | IAsyncCustomElementConstructorReference
  ;
