import { HTMLElementConstructor } from '../../../../../types/html-element-constructor.type';

export type ICustomElementConstructor = HTMLElementConstructor;
