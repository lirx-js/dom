export type IReferenceNode = Comment | Text;
