export type IDocumentFragmentOrNull = DocumentFragment | null;
