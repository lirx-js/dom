export * from './get-element-style-declaration';
export * from './get-style-property-object-of-element';
export * from './remove-style-property-of-element';
export * from './set-style-property-of-element';
export * from './set-style-property-object-or-null-of-element';
export * from './set-style-property-object-of-element';
