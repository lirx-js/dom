import { HTMLElementConstructor } from '../../light-dom/types/html-element-constructor.type';
import { createRXDOMError } from './create-rx-dom-error';

export function createMissingTagNameForComponentRXDOMError(
  component: HTMLElementConstructor,
): Error {
  return createRXDOMError(2, `Missing 'TAG_NAME' for component '${component.name}'`);
}

