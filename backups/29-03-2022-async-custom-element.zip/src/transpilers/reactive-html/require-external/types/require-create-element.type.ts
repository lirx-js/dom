export const REQUIRE_CREATE_ELEMENT_CONSTANT = 'createElement';

export type IRequireCreateElementKey = typeof REQUIRE_CREATE_ELEMENT_CONSTANT;

