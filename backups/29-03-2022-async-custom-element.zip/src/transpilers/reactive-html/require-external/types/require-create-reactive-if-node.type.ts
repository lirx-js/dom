export const REQUIRE_CREATE_REACTIVE_IF_NODE_CONSTANT = 'createReactiveIfNode';

export type IRequireCreateReactiveIfNodeKey = typeof REQUIRE_CREATE_REACTIVE_IF_NODE_CONSTANT;

