export const REQUIRE_CREATE_TEXT_NODE_CONSTANT = 'createTextNode';

export type IRequireCreateTextNodeKey = typeof REQUIRE_CREATE_TEXT_NODE_CONSTANT;
