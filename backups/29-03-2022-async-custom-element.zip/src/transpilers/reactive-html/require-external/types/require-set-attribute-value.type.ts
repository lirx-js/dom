export const REQUIRE_SET_ATTRIBUTE_VALUE_CONSTANT = 'setAttributeValue';

export type IRequireSetAttributeValueKey = typeof REQUIRE_SET_ATTRIBUTE_VALUE_CONSTANT;

