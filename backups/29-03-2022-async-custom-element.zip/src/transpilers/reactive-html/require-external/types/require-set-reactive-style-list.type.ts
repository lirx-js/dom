export const REQUIRE_SET_REACTIVE_STYLE_LIST_CONSTANT = 'setReactiveStyleList';

export type IRequireSetReactiveStyleListKey = typeof REQUIRE_SET_REACTIVE_STYLE_LIST_CONSTANT;

