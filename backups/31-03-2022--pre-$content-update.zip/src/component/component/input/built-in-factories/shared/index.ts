export * from './generate-component-with-inputs-factory';
export * from './generate-component-with-inputs-factory-result.type';
