export * from './built-in-factories/index';
export * from './component-with-inputs-factory';
export * from './extend-with-higher-order-observable-view';
