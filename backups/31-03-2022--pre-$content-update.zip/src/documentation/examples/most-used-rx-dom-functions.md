# Most used rx-dom functions


- [bootstrap](../../misc/bootstrap/bootstrap.md)
- [onNodeConnectedToWithImmediateCached](../../light-dom/node/state/on-node-connected-to/on-node-connected-to.md)
- [subscribeOnNodeConnectedTo](../../misc/subscribe-on-node-connected-to/subscribe-on-node-connected-to.md)
- [compileReactiveHTMLAsComponentTemplate](../../component/component-template/compile/compile-reactive-html-as-component-template.md)
- [compileReactiveCSSAsComponentStyle](../../component/component-style/compile/compile-reactive-css-as-component-style.md)
- [createHTMLElementModifier](element-modifiers.md)

