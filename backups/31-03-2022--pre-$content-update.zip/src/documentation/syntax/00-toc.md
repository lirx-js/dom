# Reactive HTML syntax

`reactive-html` is the name of the templating language of `rx-dom`.

It may be compiled to plain javascript with the function `compileReactiveHTMLAsComponentTemplate`.

### Example

```ts
@Component({
  name: 'app-hello-world',
  template: compileReactiveHTMLAsComponentTemplate({
    html: 'Hellow world !',
  }),
})
export class AppHelloWorldComponent extends HTMLElement {}
```


### Documentation

Here you can find the complete syntax to write your own `reactive-html`:

- [text](./reactive-text.md)
- bind:
  - [property](./attributes/bind/reactive-property.md)
  - [class](./attributes/bind/reactive-class.md)
  - [class list](./attributes/bind/reactive-class-list.md)
  - [style](./attributes/bind/reactive-style.md)
  - [style list](./attributes/bind/reactive-style-list.md)
  - [attribute](./attributes/bind/reactive-attribute.md)
- [event listener](./attributes/event/event-listener.md)
- [node modifier](./attributes/modifier/node-modifier.md)
- rx-components:
  - [rx-template](./rx-components/rx-template.md)
  - [rx-inject-template](./rx-components/rx-inject-template.md)
  - [rx-inject-content](./rx-components/rx-inject-content.md)
  - [rx-if](./rx-components/rx-if.md)
  - [rx-container](./rx-components/rx-container.md)
  - [rx-script](./rx-components/rx-script.md)


Everything which is not a special `reactive-html` syntax is interpreted as plain HTML.
