export function removeAttribute(
  element: Element,
  name: string,
): void {
  element.removeAttribute(name);
}

