import { createMissingComponentImportRXDOMError } from '../../../../../misc/errors/rx-dom-error-1--missing-component-import';
import { createCustomElementNotDefinedRXDOMError } from '../../../../../misc/errors/rx-dom-error-5--custom-element-not-defined';
import { createCustomElementsWithSameNameRXDOMError } from '../../../../../misc/errors/rx-dom-error-6--custom-elements-with-same-name';
import { getCustomElementTagName } from '../../../../custom-element/get-custom-element-tag-name';
import { isCustomElementDefined } from '../../../../custom-element/is-custom-element-defined';
import { createElement, ICreateElementOptions } from '../create-element';
import { ICreateCustomElementFunction } from './types/create-custom-element-function.type';
import { ICustomElementConstructorOrView } from './types/custom-element-constructor-or-view.type';
import { customElementRaw } from './views/build-in/custom-element-raw';
import { IGenericCustomElementView } from './views/custom-element-view.type';
import { isCustomElementView } from './views/is-custom-element-view';

export function generateCreateCustomElementFunctionFromCustomElementsList(
  customElements: ArrayLike<ICustomElementConstructorOrView>,
): ICreateCustomElementFunction {
  const customElementsMap = new Map<string, IGenericCustomElementView>();

  for (let i = 0, l = customElements.length; i < l; i++) {
    const customElementOrReference: ICustomElementConstructorOrView = customElements[i];

    const view: IGenericCustomElementView = isCustomElementView(customElementOrReference)
      ? customElementOrReference
      : customElementRaw(customElementOrReference);

    if (customElementsMap.has(view.tagName)) {
      createCustomElementsWithSameNameRXDOMError(view.tagName);
    } else {
      customElementsMap.set(view.tagName, view);
    }
  }

  return <GElement extends Element>(
    tagName: string,
    options?: ICreateElementOptions,
  ): GElement => {
    const customElementName: string = getCustomElementTagName(tagName, options);

    if (!customElementsMap.has(customElementName)) {
      throw createMissingComponentImportRXDOMError(customElementName);
    } else if (!isCustomElementDefined(customElementName)) {
      throw createCustomElementNotDefinedRXDOMError(customElementName);
    } else {
      // const requiresUpgrade: boolean = !isCustomElementDefined(customElementName); // not defined yet

      customElementsMap.get(customElementName)!.resolve();
      // .then((customElementConstructor: ICustomElementConstructor): void => {
      //   if (requiresUpgrade) {
      //     getCustomElementRegistry().upgrade(element);
      //   }
      // });

      return createElement<GElement>(tagName, options);
    }
  };
}
