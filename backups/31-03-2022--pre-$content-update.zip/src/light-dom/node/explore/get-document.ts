export function getDocument(): Document {
  return document;
}
