export * from './create-to-string-function-for-native-function';
export * from './is-patching';
export * from './patch-object-method';


