export * from './style-property-object.type';

