export * from './transpile-reactive-html-static-attribute-to-reactive-dom-js-lines';

