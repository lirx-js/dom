import { hasAttribute } from '../../../../../../../light-dom/attribute/has-attribute';
import { removeAttribute } from '../../../../../../../light-dom/attribute/remove-attribute';
import { getChildNodes } from '../../../../../../../light-dom/node/properties/get-child-nodes';
import { getTagName } from '../../../../../../../light-dom/node/properties/get-tag-name';
import { ILinesOrNull } from '../../../../../../types/lines.type';
import { IRequireExternalFunction } from '../../../../../require-external/require-external-function.type';
import {
  generateReactiveDOMJSLinesForLocalTemplateFromNodes,
} from '../../helpers/generate-reactive-dom-js-lines-for-local-template-from-nodes';
import {
  generateReactiveDOMJSLinesForLocalTemplateFromRXContainerElement,
  IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromRXContainerElement,
} from '../../helpers/generate-reactive-dom-js-lines-for-local-template-from-rx-container-element';

const TAG_NAME: string = 'rx-async-pending';
const COMMAND_NAME: string = '*async-pending';

export type IRequireExternalFunctionKeyForTranspileReactiveHTMLRXAsyncPendingToReactiveDOMJSLines = IRequireExternalFunctionKeyForGenerateReactiveDOMJSLinesForLocalTemplateFromRXContainerElement;

export function transpileReactiveHTMLRXAsyncPendingToReactiveDOMJSLines(
  node: Element,
  templateName: string,
  requireExternalFunction: IRequireExternalFunction<IRequireExternalFunctionKeyForTranspileReactiveHTMLRXAsyncPendingToReactiveDOMJSLines>,
): ILinesOrNull {
  const name: string = getTagName(node);
  if (name === TAG_NAME) {
    return [
      `// ${TAG_NAME}`,
      ...generateReactiveDOMJSLinesForLocalTemplateFromNodes(
        getChildNodes(node),
        templateName,
        null,
        requireExternalFunction,
      ),
    ];
  } else if (hasAttribute(node, COMMAND_NAME)) {
    removeAttribute(node, COMMAND_NAME);

    return [
      `// ${TAG_NAME}`,
      ...generateReactiveDOMJSLinesForLocalTemplateFromRXContainerElement(
        node,
        templateName,
        null,
        requireExternalFunction,
      ),
    ];
  } else {
    return null;
  }
}


