export const SWITCH_MAP_NAME: string = 'switchMap';
