import {
  IVirtualCustomElementNodeSlotsMap,
} from '../../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/types/slots/virtual-custom-element-node-slots-map.type';
import {
  VirtualCustomElementNode,
} from '../../../../dom-manipulation/virtual-nodes/virtual-custom-element-node/virtual-custom-element-node.class';
import { createCustomElementNotDefinedError } from '../../../errors/create-custom-element-not-defined-error';
import { createNamesMismatchError } from '../../../errors/create-names-mismatch-error';
import { ICreateComponentFromCustomElementNameOptions } from './create-component-from-custom-element-name';
import {
  ICustomElementComponent,
  ICustomElementConfig,
  ICustomElementConstructor,
  ICustomElementVirtualCustomElementNode,
} from './custom-element.types';

export interface ICreateComponentFromCustomElementReferenceOptions extends ICreateComponentFromCustomElementNameOptions {
  mustHaveSameConstructor?: boolean;
}

export function createComponentFromCustomElementReference<GElement extends HTMLElement>(
  name: string,
  getCustomElementConstructor: () => ICustomElementConstructor<GElement>,
  {
    mustBeDefined = true,
    mustHaveSameConstructor = true,
  }: ICreateComponentFromCustomElementReferenceOptions = {},
): ICustomElementComponent<GElement> {
  return {
    name,
    create: (
      slots: IVirtualCustomElementNodeSlotsMap = new Map(),
    ): ICustomElementVirtualCustomElementNode<GElement> => {
      const customElementConstructor: CustomElementConstructor | undefined = window.customElements.get(name);

      if (
        mustBeDefined
        && (customElementConstructor === void 0)
      ) {
        throw createCustomElementNotDefinedError(name);
      } else if (
        mustHaveSameConstructor
        && (customElementConstructor !== getCustomElementConstructor())
      ) {
        throw createNamesMismatchError(name);
      } else {
        return new VirtualCustomElementNode<ICustomElementConfig<GElement>>({
          name,
          slots,
        });
      }
    },
  };
}
