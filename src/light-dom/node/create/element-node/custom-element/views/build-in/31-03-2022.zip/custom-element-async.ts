import { compareCustomElementConstructorTagNamesOrThrow } from '../../helpers/compare-custom-element-constructor-tag-names-or-throw';
import { ICustomElementConstructor } from '../../types/custom-element-constructor.type';
import { createCustomElementView } from '../create-custom-element-view';
import { ICustomElementView } from '../custom-element-view.type';

export interface IGetCustomElementConstructorAsyncFunction<GCustomElementConstructor extends ICustomElementConstructor> {
  (): Promise<GCustomElementConstructor>;
}

export function customElementAsync<// generics
  GTagName extends string,
  GCustomElementConstructor extends ICustomElementConstructor
  //
  >(
  tagName: GTagName,
  getCustomElementConstructorAsync: IGetCustomElementConstructorAsyncFunction<GCustomElementConstructor>,
): ICustomElementView<GTagName, GCustomElementConstructor> {
  return createCustomElementView<GTagName, GCustomElementConstructor>(
    tagName,
    (): Promise<GCustomElementConstructor> => {
      return getCustomElementConstructorAsync()
        .then((customElementConstructor: GCustomElementConstructor): GCustomElementConstructor => {
          compareCustomElementConstructorTagNamesOrThrow(customElementConstructor, tagName);
          return customElementConstructor;
        });
    },
  );
}
