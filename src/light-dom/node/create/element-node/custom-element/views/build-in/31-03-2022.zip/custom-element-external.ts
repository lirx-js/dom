import { compareCustomElementConstructorTagNamesOrThrow } from '../../helpers/compare-custom-element-constructor-tag-names-or-throw';
import { getCustomElementConstructorTagNameOrThrow } from '../../helpers/get-custom-element-constructor-tag-name-or-throw';
import { ICustomElementConstructor } from '../../types/custom-element-constructor.type';
import { createCustomElementView } from '../create-custom-element-view';
import { ICustomElementView } from '../custom-element-view.type';

// export function customElementExternal<// generics
//   GTagName extends string,
//   GCustomElementConstructor extends ICustomElementConstructor
//   //
//   >(
//   customElementConstructor: GCustomElementConstructor,
// ): ICustomElementView<GTagName, GCustomElementConstructor> {
//   return createCustomElementView<GTagName, GCustomElementConstructor>(
//     getCustomElementConstructorTagNameOrThrow(customElementConstructor) as GTagName,
//     (): Promise<GCustomElementConstructor> => {
//       return Promise.resolve(customElementConstructor);
//     },
//   );
// }

export interface IGetCustomElementConstructorExternalFunction<GCustomElementConstructor extends ICustomElementConstructor> {
  (): Promise<GCustomElementConstructor>;
}

export function customElementExternal<// generics
  GTagName extends string,
  GCustomElementConstructor extends ICustomElementConstructor
  //
  >(
  tagName: GTagName,
  getCustomElementConstructorExternal: IGetCustomElementConstructorExternalFunction<GCustomElementConstructor>,
): ICustomElementView<GTagName, GCustomElementConstructor> {
  return createCustomElementView<GTagName, GCustomElementConstructor>(
    tagName,
    (): Promise<GCustomElementConstructor> => {
      return getCustomElementConstructorExternal()
        .then((customElementConstructor: GCustomElementConstructor): GCustomElementConstructor => {
          compareCustomElementConstructorTagNamesOrThrow(customElementConstructor, tagName);
          return customElementConstructor;
        });
    },
  );
}

