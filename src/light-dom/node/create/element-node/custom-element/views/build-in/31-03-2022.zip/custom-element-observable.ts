import { IDefaultNotificationsUnion, IObservable, toPromiseLast } from '@lifaon/rx-js-light';
import { ICustomElementConstructor } from '../../types/custom-element-constructor.type';
import { ICustomElementView } from '../custom-element-view.type';
import { customElementAsync } from './custom-element-async';

export function customElementObservable<// generics
  GTagName extends string,
  GCustomElementConstructor extends ICustomElementConstructor
  //
  >(
  tagName: GTagName,
  customElementConstructorObservable: IObservable<IDefaultNotificationsUnion<GCustomElementConstructor>>,
): ICustomElementView<GTagName, GCustomElementConstructor> {
  return customElementAsync<GTagName, GCustomElementConstructor>(
    tagName,
    (): Promise<GCustomElementConstructor> => {
      return toPromiseLast<GCustomElementConstructor>(customElementConstructorObservable);
    },
  );
}
