import { compareCustomElementConstructorTagNamesOrThrow } from '../../helpers/compare-custom-element-constructor-tag-names-or-throw';
import { ICustomElementConstructor } from '../../types/custom-element-constructor.type';
import { createCustomElementView } from '../create-custom-element-view';
import { ICustomElementView } from '../custom-element-view.type';

export interface IGetCustomElementConstructorFunction<GCustomElementConstructor extends ICustomElementConstructor> {
  (): GCustomElementConstructor;
}

export function customElementRef<// generics
  GTagName extends string,
  GCustomElementConstructor extends ICustomElementConstructor
  //
  >(
  tagName: GTagName,
  getCustomElementConstructor: IGetCustomElementConstructorFunction<GCustomElementConstructor>,
): ICustomElementView<GTagName, GCustomElementConstructor> {
  return createCustomElementView<GTagName, GCustomElementConstructor>(
    tagName,
    (): Promise<GCustomElementConstructor> => {
      return new Promise<GCustomElementConstructor>((
        resolve: (value: GCustomElementConstructor) => void,
      ): void => {
        const customElementConstructor: GCustomElementConstructor = getCustomElementConstructor();
        compareCustomElementConstructorTagNamesOrThrow(customElementConstructor, tagName);
        resolve(customElementConstructor);
      });
    },
  );
}
