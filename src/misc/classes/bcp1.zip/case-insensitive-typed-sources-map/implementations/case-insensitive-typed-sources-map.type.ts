import { ITypedSourcesMapEntriesTuple } from '../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import { ICaseInsensitiveTypedSourcesMapTraitsCollection } from '../traits/case-insensitive-typed-sources-map.traits-collection';

export type ICaseInsensitiveTypedSourcesMap<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> = ICaseInsensitiveTypedSourcesMapTraitsCollection<GTypedSourcesTuple>;
