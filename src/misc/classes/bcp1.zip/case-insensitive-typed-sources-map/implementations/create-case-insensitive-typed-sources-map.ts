import { IMulticastReplayLastSource, IObservable, IObserver } from '@lirx/core';
import { createTypedSourcesMap } from '../../typed-sources-map/implementations/create-typed-sources-map';
import {
  InferTypedSourcesMapEntriesTupleValueFromKey,
} from '../../typed-sources-map/types/infer-typed-sources-map-entries-tuple-value-from-key.infer';
import {
  ITypedSourcesMapEntriesTupleToEntriesTuple,
} from '../../typed-sources-map/types/typed-sources-map-entries-tuple-to-entries-tuple.infer';
import { ITypedSourcesMapEntriesTuple } from '../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey,
} from '../types/infer-typed-map-entries-tuple-key-from-case-insensitive-key.infer';
import { ICaseInsensitiveTypedSourcesMap } from './case-insensitive-typed-sources-map.type';

export function createCaseInsensitiveTypedSourcesMap<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple>(
  _entries: ITypedSourcesMapEntriesTupleToEntriesTuple<GTypedSourcesTuple>,
): ICaseInsensitiveTypedSourcesMap<GTypedSourcesTuple> {
  const {
    has,
    getSource,
    get$,
    get,
    $set,
    set,
    entries,
  } = createTypedSourcesMap<GTypedSourcesTuple>(_entries);

  const _lowerCaseKeys = new Map<string, string>();

  for (let i = 0, l = _entries.length; i < l; i++) {
    const [key] = _entries[i];
    const lowerCaseKey: string = key.toLowerCase();
    if (_lowerCaseKeys.has(lowerCaseKey)) {
      throw new Error(`Found two keys with the same case insensitive value: ${key} - ${_lowerCaseKeys.get(lowerCaseKey)!}`);
    } else {
      _lowerCaseKeys.set(lowerCaseKey, key);
    }
  }

  const getCaseInsensitiveKey = <GKey extends string>(
    key: GKey,
  ): InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey<GTypedSourcesTuple, GKey> => {
    const _key: string | undefined = _lowerCaseKeys.get(key.toLowerCase());

    if (_key === void 0) {
      throw new Error(`Invalid key: ${key}`);
    } else {
      return _key as InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey<GTypedSourcesTuple, GKey>;
    }
  };

  const hasCaseInsensitive = (
    key: string,
  ): boolean => {
    return _lowerCaseKeys.has(key.toLowerCase());
  };

  const getSourceCaseInsensitive = <GKey extends string>(
    key: GKey,
  ): IMulticastReplayLastSource<InferTypedSourcesMapEntriesTupleValueFromKey<GTypedSourcesTuple, InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey<GTypedSourcesTuple, GKey>>> => {
    return getSource(getCaseInsensitiveKey<GKey>(key));
  };

  const get$CaseInsensitive = <GKey extends string>(
    key: GKey,
  ): IObservable<InferTypedSourcesMapEntriesTupleValueFromKey<GTypedSourcesTuple, InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey<GTypedSourcesTuple, GKey>>> => {
    return get$(getCaseInsensitiveKey<GKey>(key));
  };

  const getCaseInsensitive = <GKey extends string>(
    key: GKey,
  ): InferTypedSourcesMapEntriesTupleValueFromKey<GTypedSourcesTuple, InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey<GTypedSourcesTuple, GKey>> => {
    return get(getCaseInsensitiveKey<GKey>(key));
  };

  const $setCaseInsensitive = <GKey extends string>(
    key: GKey,
  ): IObserver<InferTypedSourcesMapEntriesTupleValueFromKey<GTypedSourcesTuple, InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey<GTypedSourcesTuple, GKey>>> => {
    return $set(getCaseInsensitiveKey<GKey>(key));
  };

  const setCaseInsensitive = <GKey extends string>(
    key: GKey,
    value: InferTypedSourcesMapEntriesTupleValueFromKey<GTypedSourcesTuple, InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey<GTypedSourcesTuple, GKey>>,
  ): void => {
    set(getCaseInsensitiveKey<GKey>(key), value);
  };

  return {
    has,
    getSource,
    get$,
    get,
    $set,
    set,
    entries,
    getCaseInsensitiveKey,
    hasCaseInsensitive,
    getSourceCaseInsensitive,
    get$CaseInsensitive,
    getCaseInsensitive,
    $setCaseInsensitive,
    setCaseInsensitive,
  };
}
