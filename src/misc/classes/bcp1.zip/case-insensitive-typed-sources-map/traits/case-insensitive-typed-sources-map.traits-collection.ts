import { ITypedSourcesMapTraitsCollection } from '../../typed-sources-map/traits/typed-sources-map.traits-collection';
import { ITypedSourcesMapEntriesTuple } from '../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  ICaseInsensitiveTypedSourcesMap$SetCaseInsensitiveTrait
} from './$set-case-insensitive/case-insensitive-typed-sources-map.$set-case-insensitive.trait';
import {
  ICaseInsensitiveTypedSourcesMapGet$CaseInsensitiveTrait
} from './get$-case-insensitive/case-insensitive-typed-sources-map.get$-case-insensitive.trait';
import {
  ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveKeyTrait
} from './get-case-insensitive-key/case-insensitive-typed-sources-map.get-case-insensitive-key.trait';
import {
  ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveTrait
} from './get-case-insensitive/case-insensitive-typed-sources-map.get-case-insensitive.trait';
import {
  ICaseInsensitiveTypedSourcesMapGetSourceCaseInsensitiveTrait
} from './get-source-case-insensitive/case-insensitive-typed-sources-map.get-source-case-insensitive.trait';
import {
  ICaseInsensitiveTypedSourcesMapHasCaseInsensitiveTrait
} from './has-case-insensitive/case-insensitive-typed-sources-map.has-case-insensitive.trait';
import {
  ICaseInsensitiveTypedSourcesMapSetCaseInsensitiveTrait
} from './set-case-insensitive/case-insensitive-typed-sources-map.set-case-insensitive.trait';

export interface ICaseInsensitiveTypedSourcesMapTraitsCollection<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> extends ITypedSourcesMapTraitsCollection<GTypedSourcesTuple>, //
  ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveKeyTrait<GTypedSourcesTuple>,
  ICaseInsensitiveTypedSourcesMap$SetCaseInsensitiveTrait<GTypedSourcesTuple>,
  ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveTrait<GTypedSourcesTuple>,
  ICaseInsensitiveTypedSourcesMapGet$CaseInsensitiveTrait<GTypedSourcesTuple>,
  ICaseInsensitiveTypedSourcesMapGetSourceCaseInsensitiveTrait<GTypedSourcesTuple>,
  ICaseInsensitiveTypedSourcesMapHasCaseInsensitiveTrait<GTypedSourcesTuple>,
  ICaseInsensitiveTypedSourcesMapSetCaseInsensitiveTrait<GTypedSourcesTuple>
  //
{
}
