import { ITypedSourcesMapEntriesTuple } from '../../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveFunction,
} from './case-insensitive-typed-sources-map.get-case-insensitive.function';

export interface ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveTrait<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> {
  getCaseInsensitive: ICaseInsensitiveTypedSourcesMapGetCaseInsensitiveFunction<GTypedSourcesTuple>;
}
