import { ITypedSourcesMapEntriesTuple } from '../../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import { ICaseInsensitiveTypedSourcesMapGetSourceCaseInsensitiveFunction } from './case-insensitive-typed-sources-map.get-source-case-insensitive.function';

export interface ICaseInsensitiveTypedSourcesMapGetSourceCaseInsensitiveTrait<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> {
  getSourceCaseInsensitive: ICaseInsensitiveTypedSourcesMapGetSourceCaseInsensitiveFunction<GTypedSourcesTuple>;
}
