import { ITypedSourcesMapEntriesTuple } from '../../../typed-sources-map/types/typed-sources-map-entries-tuple.type';

export interface ICaseInsensitiveTypedSourcesMapHasCaseInsensitiveFunction<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> {
  (
    key: string,
  ): boolean;
}
