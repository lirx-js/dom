import { ITypedSourcesMapEntriesTuple } from '../../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  ICaseInsensitiveTypedSourcesMapHasCaseInsensitiveFunction
} from './case-insensitive-typed-sources-map.has-case-insensitive.function';

export interface ICaseInsensitiveTypedSourcesMapHasCaseInsensitiveTrait<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> {
  hasCaseInsensitive: ICaseInsensitiveTypedSourcesMapHasCaseInsensitiveFunction<GTypedSourcesTuple>;
}
