import { ITypedSourcesMapEntriesTuple } from '../../../typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  ICaseInsensitiveTypedSourcesMapSetCaseInsensitiveFunction,
} from './case-insensitive-typed-sources-map.set-case-insensitive.function';

export interface ICaseInsensitiveTypedSourcesMapSetCaseInsensitiveTrait<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple> {
  setCaseInsensitive: ICaseInsensitiveTypedSourcesMapSetCaseInsensitiveFunction<GTypedSourcesTuple>;
}
