import { ITypedMapEntriesTuple } from '../../typed-map/types/typed-map-entries-tuple.type';
import { InferTypedSourcesMapEntriesTupleKeys } from '../../typed-sources-map/types/infer-typed-sources-map-entries-tuple-keys.infer';

export type InferTypedMapEntriesTupleKeyFromCaseInsensitiveKey<// generics
  GEntriesTuple extends ITypedMapEntriesTuple,
  GKey extends string
  //
> = {
  [Key in keyof GEntriesTuple]: Lowercase<GEntriesTuple[Key][0]> extends Lowercase<GKey>
    ? (
      GEntriesTuple[Key][0] extends InferTypedSourcesMapEntriesTupleKeys<GEntriesTuple>
        ? GEntriesTuple[Key][0]
        : never
      )
    : never;
}[number];
