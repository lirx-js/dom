import { InferTypedMapEntriesTupleKeys } from './infer-typed-map-entries-tuple-keys.infer';
import { ITypedMapEntriesTuple } from './typed-map-entries-tuple.type';
import { ITypedMapEntry } from './typed-map-entry.type';

export type InferTypedMapEntriesTupleValueFromKey<// generics
  GEntriesTuple extends ITypedMapEntriesTuple,
  GKey extends string
  //
  > = {
  [Key in keyof GEntriesTuple]: Lowercase<GEntriesTuple[Key][0]> extends Lowercase<GKey>
    ? GEntriesTuple[Key][1]
    : never;
}[number];

