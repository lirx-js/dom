import { IGenericTypedMapEntry } from './typed-map-entry.type';

export type ITypedMapEntriesTuple = readonly IGenericTypedMapEntry[];
