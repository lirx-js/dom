import { inlineLastLines } from '../../../../../../../__src/transpilers/misc/lines/functions/after-last-line';
import { indentLines } from '../../../../../../../__src/transpilers/misc/lines/functions/indent-lines';
import { ILines } from '../../../../../../../__src/transpilers/misc/lines/lines.type';
import {
  ITranspileCreateReactiveForLoopNodeToJSLinesFunction,
  ITranspileCreateReactiveForLoopNodeToJSLinesOptions,
} from '../../transpilers/transpile-create-reactive-for-loop-node-to-js-lines.type';

export const transpileCreateReactiveForLoopNodeToJSLines: ITranspileCreateReactiveForLoopNodeToJSLinesFunction = (
  {
    items,
    template,
    trackBy,
  }: ITranspileCreateReactiveForLoopNodeToJSLinesOptions,
): ILines => {
  return [
    `new VirtualReactiveForLoopNode(`,
    ...indentLines([
      ...inlineLastLines(
        items,
        [','],
      ),
      ...inlineLastLines(
        template,
        [','],
      ),
      ...(
        (trackBy === null)
          ? []
          : inlineLastLines(
            trackBy,
            [','],
          )
      ),
    ]),
    `)`,
  ];
};


