import { inlineLastLines } from '../../../../../../../__src/transpilers/misc/lines/functions/after-last-line';
import { wrapLinesWithRoundBrackets } from '../../../../../../../__src/transpilers/misc/lines/functions/wrap-lines-with-round-brackets';
import { ILines } from '../../../../../../../__src/transpilers/misc/lines/lines.type';
import {
  ITranspileCreateReactiveTextNodeToJSLinesFunction,
  ITranspileCreateReactiveTextNodeToJSLinesOptions,
} from '../../transpilers/transpile-create-reactive-text-node-to-js-lines.type';

export const transpileCreateReactiveTextNodeToJSLines: ITranspileCreateReactiveTextNodeToJSLinesFunction = (
  {
    value,
  }: ITranspileCreateReactiveTextNodeToJSLinesOptions,
): ILines => {
  return inlineLastLines(
    [`lirx_dom_internal_create_virtual_reactive_text_node`],
    wrapLinesWithRoundBrackets(value),
  );
};


