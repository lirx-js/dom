import { inlineLastLines } from '../../../../../../../__src/transpilers/misc/lines/functions/after-last-line';
import { wrapLinesWithRoundBrackets } from '../../../../../../../__src/transpilers/misc/lines/functions/wrap-lines-with-round-brackets';
import { ILines } from '../../../../../../../__src/transpilers/misc/lines/lines.type';
import {
  ITranspileCreateStaticTextNodeToJSLinesFunction,
  ITranspileCreateStaticTextNodeToJSLinesOptions,
} from '../../transpilers/transpile-create-static-text-node-to-js-lines.type';

export const transpileCreateStaticTextNodeToJSLines: ITranspileCreateStaticTextNodeToJSLinesFunction = (
  {
    value,
  }: ITranspileCreateStaticTextNodeToJSLinesOptions,
): ILines => {
  return inlineLastLines(
    [`lirx_dom_internal_create_virtual_text_node`],
    wrapLinesWithRoundBrackets(value),
  );
};


