import { inlineLastLines } from '../../../../../../../__src/transpilers/misc/lines/functions/after-last-line';
import { ILines } from '../../../../../../../__src/transpilers/misc/lines/lines.type';
import {
  ITranspileSetReactiveEventListenerToJSLinesFunction,
  ITranspileSetReactiveEventListenerToJSLinesOptions,
} from '../../transpilers/transpile-set-reactive-event-listener-to-js-lines.type';

export const transpileSetReactiveEventListenerToJSLines: ITranspileSetReactiveEventListenerToJSLinesFunction = (
  {
    node,
    name,
    value,
    observableMode,
  }: ITranspileSetReactiveEventListenerToJSLinesOptions,
): ILines => {
  return inlineLastLines(
    node,
    [
      observableMode
        ? `.setReactiveEventListenerFromObservable(`
        : `.setReactiveEventListener(`,
    ],
    name,
    [','],
    value,
    [');'],
  );
};


