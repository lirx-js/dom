import { inlineLastLines } from '../../../../../../../__src/transpilers/misc/lines/functions/after-last-line';
import { ILines } from '../../../../../../../__src/transpilers/misc/lines/lines.type';
import {
  ITranspileSetReactivePropertyToJSLinesFunction,
  ITranspileSetReactivePropertyToJSLinesOptions,
} from '../../transpilers/transpile-set-reactive-property-to-js-lines.type';

export const transpileSetReactivePropertyToJSLines: ITranspileSetReactivePropertyToJSLinesFunction = (
  {
    node,
    name,
    value,
  }: ITranspileSetReactivePropertyToJSLinesOptions,
): ILines => {
  return inlineLastLines(
    node,
    [`.setReactiveProperty(`],
    name,
    [', '],
    value,
    [');'],
  );
};


