import { toObservableThrowIfUndefined } from '@lirx/core';
import { virtualElementNodeAppendClassNames } from '../../../../../dom-manipulation/helpers/misc/virtual-element-node-append-class-names';
import {
  VirtualReactiveAsyncNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-async-node/virtual-reactive-async-node.class';
import {
  VirtualReactiveElementNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-element-node/virtual-reactive-element-node.class';
import {
  VirtualReactiveForLoopNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-for-loop-node/virtual-reactive-for-loop-node.class';
import {
  VirtualReactiveIfNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-if-node/virtual-reactive-if-node.class';
import {
  VirtualReactiveSwitchNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-switch-node/virtual-reactive-switch-node.class';
import {
  VirtualReactiveTextNode,
} from '../../../../../dom-manipulation/virtual-nodes/virtual-reactive-text-node/virtual-reactive-text-node.class';
import { VirtualTextNode } from '../../../../../dom-manipulation/virtual-nodes/virtual-text-node/virtual-text-node';

export const VALUES_TO_IMPORT_FOR_VIRTUAL_NODE_BASED_REACTIVE_HTML = {
  VirtualTextNode,
  VirtualReactiveElementNode,
  VirtualReactiveTextNode,
  VirtualReactiveIfNode,
  VirtualReactiveSwitchNode,
  VirtualReactiveForLoopNode,
  VirtualReactiveAsyncNode,
  toObservableThrowIfUndefined,
  virtualElementNodeAppendClassNames,
};
