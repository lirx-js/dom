import { getElementTagName } from '../../../../../../../misc/dom/get-element-tag-name';
import { createDuplicateTemplateError } from '../../../../../../misc/errors/create-duplicate-template-error';
import { createInvalidAttributeFoundError } from '../../../../../../misc/errors/create-invalid-attribute-found-error';
import { createMissingAttributeError } from '../../../../../../misc/errors/create-missing-attribute-error';
import { createSlotAlreadyExistsError } from '../../../../../../misc/errors/create-slot-already-exists-error';
import { linesOrNullToLines } from '../../../../../../misc/lines/functions/lines-or-null-to-lines';
import { ILinesOrNull } from '../../../../../../misc/lines/lines-or-null.type';
import { IHavingPrimaryTranspilersOptions } from '../../../../../primary/primary-transpilers.type';
import {
  ITranspileCreateReactiveCustomElementNodeToJSLinesOptionsSlotsMap,
} from '../../../../../primary/transpilers/transpile-create-reactive-custom-element-node-to-js-lines.type';
import { transpileReactiveHTMLNodesToJSLines } from '../../../../nodes/transpile-reactive-html-nodes-to-js-lines';
import {
  extractLetPropertyFromReactiveHTMLAttribute,
  ILetProperty,
} from '../../../../rx-component/transpilers/helpers/extract-let-property-from-reactive-html-attribute';
import {
  transpileReactiveHTMLRXInjectSlotChildNodesToLines,
} from '../../../../rx-component/transpilers/rx-inject-slot/transpile-reactive-html-rx-inject-slot-child-nodes-to-lines';
import {
  generateLetPropertyLinesForTemplate
} from '../../../../rx-component/transpilers/rx-template/generate-let-property-lines-for-template';
import { transpileReactiveHTMLElementToJSLines } from '../../../transpile-reactive-html-element-to-js-lines';

export const RX_SLOT_TAG_NAME = 'rx-slot';
export const RX_SLOT_COMMAND = '*slot';

const NAME_ATTRIBUTE_NAME: string = 'name';
const PROXY_ATTRIBUTE_NAME: string = 'proxy';

export interface ITranspileReactiveHTMLCustomElementChildElementToSlotsOfJSLinesOptions extends IHavingPrimaryTranspilersOptions {
  node: Element;
  slots: ITranspileCreateReactiveCustomElementNodeToJSLinesOptionsSlotsMap;
}

// TODO add support for let properties

export function transpileReactiveHTMLCustomElementChildElementToSlotsOfJSLines(
  {
    node,
    slots,
    ...options
  }: ITranspileReactiveHTMLCustomElementChildElementToSlotsOfJSLinesOptions,
): void {
  if (getElementTagName(node) === RX_SLOT_TAG_NAME) {
    let name: string | null = null;
    let proxy: string | null = null;

    // const name: string | null = node.getAttribute('name');
    // const proxy: string | null = node.getAttribute('proxy');

    const letProperties: ILetProperty[] = [];

    const attributes: Attr[] = Array.from(node.attributes);
    for (let i = 0, l = attributes.length; i < l; i++) {
      const attribute: Attr = attributes[i];

      const letProperty: ILetProperty | null = extractLetPropertyFromReactiveHTMLAttribute(attribute);
      if (letProperty === null) {
        if (attribute.name === NAME_ATTRIBUTE_NAME) {
          name = attribute.value;
        } else {
          if (attribute.name === PROXY_ATTRIBUTE_NAME) {
            proxy = attribute.value;
          } else {
            throw createInvalidAttributeFoundError(attribute);
          }
        }
      } else {
        letProperties.push(letProperty);
      }
    }

    console.log('letProperties', letProperties);
    // const letPropertiesLines: ILinesOrNull = generateLetPropertyLinesForTemplate(letProperties);

    if (name === null) {
      if (proxy === null) {
        throw createMissingAttributeError('name', node);
      } else {
        slots.set(proxy, {
          bodyLines: transpileReactiveHTMLRXInjectSlotChildNodesToLines({
            ...options,
            slotName: proxy,
            nodes: node.childNodes,
          }),
          letProperties,
        });
      }
    } else if (slots.has(name)) {
      throw createSlotAlreadyExistsError(name, node.parentElement!);
    } else {
      console.log(transpileReactiveHTMLNodesToJSLines({
        ...options,
        nodes: node.childNodes,
      }));
      if (proxy === null) {
        slots.set(name, {
          bodyLines: linesOrNullToLines(transpileReactiveHTMLNodesToJSLines({
            ...options,
            nodes: node.childNodes,
          })),
          letProperties,
        });
      } else {
        const proxyName: string = (proxy === '')
          ? name
          : proxy;

        slots.set(name, {
          bodyLines: transpileReactiveHTMLRXInjectSlotChildNodesToLines({
            ...options,
            slotName: proxyName,
            nodes: node.childNodes,
          }),
          letProperties,
        });
      }
    }
  } else {
    let name: string | null = node.getAttribute(RX_SLOT_COMMAND);
    if (name === null) {
      const lines: ILinesOrNull = transpileReactiveHTMLElementToJSLines({
        ...options,
        node: node as Element,
      });
      if (lines !== null) {
        slots.get('*')!.bodyLines.push(...lines);
      }
    } else if (slots.has(name)) {
      throw createSlotAlreadyExistsError(name, node.parentElement!);
    } else {
      node.removeAttribute(RX_SLOT_COMMAND);
      slots.set(name, {
        bodyLines: linesOrNullToLines(transpileReactiveHTMLElementToJSLines({
          ...options,
          node: node as Element,
        })),
        letProperties: [],
      });
    }
  }
}
